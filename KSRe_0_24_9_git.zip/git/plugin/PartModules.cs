﻿using I2.Loc;
using KSP.Game;
using KSP;
using KSP.Modules;
using KSP.Sim;
using KSP.Sim.Definitions;
using KSP.Sim.impl;
using KSP.Sim.ResourceSystem;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using System.Data;

namespace KSRe {

    [Serializable]
    public class Data_Damage : ModuleData {

        [KSPState]
        public double damage;

        [KSPState]
        public Dictionary<string, double> records;

        public override Type ModuleType => typeof(Module_Damage);

    }

    [DisallowMultipleComponent]
    public class Module_Damage : PartBehaviourModule {

        [SerializeField]
        protected Data_Damage dataDamage;
        protected Module_RCS moduleRCS;
        // protected Data_ControlSurface dataCtrlSrf;
        private double initRepairDmg;
        private double lastSlowUpdateUT;
        private float updateDeltaT;
        internal double lastSlowUpdateDmg;

        public override Type PartComponentModuleType => typeof(PartComponentModule_Damage);
        public virtual Data_Damage DataDmg => dataDamage;
        public virtual PartComponentModule_Damage CompModuleDmg => ComponentModule as PartComponentModule_Damage;

        protected override void AddDataModules() => DataModules.TryAddUnique(dataDamage, out dataDamage);
        protected override void OnInitialize() {
            if (PartBackingMode != PartBackingModes.Flight) return;
            lastSlowUpdateUT = Game.UniverseModel.UniverseTime;
            updateDeltaT = (float)CompModuleDmg?.Modifier;
        }
        protected override void OnStart() {
            TryGetComponent(out moduleRCS);
            // if (TryGetComponent(out Module_ControlSurface moduleCtrlSrf))
            //     moduleCtrlSrf.DataModules.TryGetByType(out dataCtrlSrf);
            // moduleRCS.DataModules.TryGetByType(out dataRCS);
        }
        protected override void OnModuleUpdate(float deltaTime) {
            updateDeltaT += deltaTime;
            if (updateDeltaT > 1) {
                OnModuleSlowUpdate(Game.UniverseModel.UniverseTime - lastSlowUpdateUT);
                lastSlowUpdateUT = Game.UniverseModel.UniverseTime;
                updateDeltaT = 0;
            }
        }
        protected override void OnModuleFixedUpdate(float fixedDeltaTime) {
            if (part?.IsSimObjectDestroyed() ?? true) return;
            if (vessel.SimObjectComponent.geeForce > part.SimObjectComponent.PartData.crashTolerance)
                CompModuleDmg.AddDamage(fixedDeltaTime * (Math.Pow(1.047, (vessel.SimObjectComponent.geeForce / (part.SimObjectComponent.PartData.crashTolerance * 2)) * 50) - 1), "Flight_GeeForces");
            // CompModuleDmg.AddDamage(fixedDeltaTime * Math.Min(vessel.SimObjectComponent.geeForce - part.SimObjectComponent.PartData.crashTolerance, 400.0) * 0.5);
            double heatDmgThreshold = part.SimObjectComponent.PartData.maxTemp * 0.6;
            if (part.SimObjectComponent.ThermalData.Temperature > heatDmgThreshold) {
                bool ablate = false;
                if (part.SimObjectComponent.PartData.family == "0450-Heat Shield")
                    if (part.SimObjectComponent.PartData.partName == "heatshield_2v_inflatable") ablate = true;
                    else if (part.SimObjectComponent.PartOwner.ContainerGroup.GetStoredResourcesTotalMass() > 0) ablate = true;
                // double tempDiff = part.SimObjectComponent.ThermalData.Temperature - part.SimObjectComponent.PartData.maxTemp * 0.6;
                // CompModuleDmg.AddDamage(fixedDeltaTime * tempDiff * 0.015);
                double dmg = fixedDeltaTime * (Math.Pow(1.047, ((part.SimObjectComponent.ThermalData.Temperature - heatDmgThreshold) / (part.SimObjectComponent.PartData.maxTemp - heatDmgThreshold)) * 75) - 1);
                if (ablate) CompModuleDmg.AddRecords(dmg, "Flight_Heat");
                else CompModuleDmg.AddDamage(dmg, "Flight_Heat");
            }
            if (this is Module_DamageEngine) return;
            if (moduleRCS?.isOperational ?? false)
                CompModuleDmg.AddDamage(fixedDeltaTime * 0.1, "Propulsion_RCS");
            if (part.SimObjectComponent.PartData.family == "0430-Landing Gear" || part.SimObjectComponent.PartData.family == "0440-Wheel")
                if (vessel.SimObjectComponent.SurfaceVelocity.magnitude > 0.1 && part.vessel.SimObjectComponent.VesselScienceRegionSituation.ResearchLocation?.ScienceSituation == KSP.Game.Science.ScienceSitutation.Landed) {
                    double dmg = fixedDeltaTime * (Math.Pow(1.047, (vessel.SimObjectComponent.SurfaceVelocity.magnitude / (part.SimObjectComponent.PartData.crashTolerance * 2)) * 25) - 1);
                    CompModuleDmg.AddDamage(dmg, part.SimObjectComponent.PartData.family == "0440-Wheel" ? "Electrical_Wheel" : "Aeronautics_LandingGear");
                }
            // if (dataCtrlSrf?.IsCtrlSurfaceActive ?? false)
                // CompModuleDmg.AddDamage(fixedDeltaTime * 0.075, "Aeronautics_ControlSurface");
        }

        protected virtual void OnModuleSlowUpdate(double fixedDeltaT) {
            // if (part.SimObjectComponent.PartData.category == PartCategories.Engine) {
            if (lastSlowUpdateDmg != 0 && lastSlowUpdateDmg < CompModuleDmg.FailPoint && CompModuleDmg.GetDamage() > CompModuleDmg.FailPoint)
                CompModuleDmg.ApplyFault();
            // }
            if (ReUtil.IsPALActive(vessel.SimObjectComponent)) {
                if (ReUtil.IsPALActive(level: 7, bypassVessel: true) && CompModuleDmg.GetDamage(false) > 85 && lastSlowUpdateDmg <= 85)
                    CompModuleDmg.PushNotify("/Heavy");
                else if (ReUtil.IsPALActive(level: 8, bypassVessel: true) && CompModuleDmg.GetDamage(false) > 35 && lastSlowUpdateDmg <= 35)
                    CompModuleDmg.PushNotify("/Medium");
            }
            lastSlowUpdateDmg = CompModuleDmg.GetDamage(false);
            if (RePlugin.UIPart?.Guid == part.SimObjectComponent.Guid) {
                if (RePlugin.inspectTicks == -1)
                    RePlugin.inspectTicks = 7; // (int)Math.Round(part.SimObjectComponent.PartData.PartSizeDiameter * 1.5)
                RePlugin.UIPartDmg = CompModuleDmg.GetDamage();
            }
            if (RePlugin.repairers.Count == 0) return;
            if (!RePlugin.repairers.Any(r => r.TargetGuid == part.SimObjectComponent.Guid)) return;
            double repairMax = 15.01 + 5 * (vessel.SimObjectComponent.TimeSinceLaunch / 7884000d);
            if (initRepairDmg == 0) {
                if (CompModuleDmg.GetDamage() < repairMax) {
                    RePlugin.repairers.RemoveAll(r => r.TargetGuid == part.SimObjectComponent.Guid);
                    return;
                }
                initRepairDmg = CompModuleDmg.GetDamage();
            }
            CompModuleDmg.AddDamage(-0.02 * fixedDeltaT * RePlugin.repairers.Count(r => r.TargetGuid == part.SimObjectComponent.Guid));
            if (CompModuleDmg.GetDamage() < repairMax) {
                CompModuleDmg.SetDamage(repairMax);
                CompModuleDmg.isLeaking = false;
                //if (RePlugin.repairers.Any(r => r.Guid == RePlugin.activeVessel.Guid))
                //    RePlugin.lockUI = false;
                RePlugin.repairers.RemoveAll(r => r.TargetGuid == part.SimObjectComponent.Guid);
                CompModuleDmg.PushNotify("/Repaired");
                if (ReUtil.IsGameSandbox()) return;
                float diffScale;
                if (!Game.SessionManager.TryGetDifficultyOptionState("ScienceRewards", out diffScale)) diffScale = 1f;
                int sciGain = Math.Max(1, (int)Math.Round(initRepairDmg * 0.025 * (ReUtil.GetSciBonus("Engineering") + 1) * diffScale));
                ReUtil.AddScience(sciGain);
                RePlugin.AddRocketScience("Engineering_Repairs", sciGain);
                initRepairDmg = 0;
            } else {
                if (vessel.SimObjectComponent.SimulationObject.Telemetry.CommNetConnectionStatus != ConnectionNodeStatus.Connected)
                    RePlugin.repairers.RemoveAll(r => r.Guid == vessel.SimObjectComponent.Guid);
                foreach (VesselComponent vessel in Game?.ViewController?.VesselsInRange.Where(v => RePlugin.repairers.Any(r => r.Guid == v.Guid)))
                    if (Position.Distance(vessel.transform.Position, part.SimObjectComponent.transform.Position) > part.SimObjectComponent.PartData.PartSizeDiameter + 1.5)
                        RePlugin.repairers.RemoveAll(r => r.Guid == vessel.Guid);
            }
        }

    }

    public class PartComponentModule_Damage : PartComponentModule {

        private Data_Damage dataDamage;
        private double lastDailyUpdateUT;
        // private double lastSlowUpdateUT;
        internal double Modifier { get; private set; }
        internal double FailPoint { get; private set; }
        internal bool isLeaking;

        public override Type PartBehaviourModuleType => typeof(Module_Damage);
        public virtual Data_Damage DataDmg => dataDamage;

        public override void OnStart(double universalTime) {
            DataModules.TryGetByType(out dataDamage);
            UnityEngine.Random.InitState(Part.Guid.GetHashCode());
            Modifier = UnityEngine.Random.value;
            lastDailyUpdateUT = universalTime - 21600 * Modifier;
            // lastSlowUpdateUT = universalTime - Modifier * 2;
            FailPoint = ReUtil.mfParts.Values.Any(p => p.Contains(Part.PartData.partName)) && !ReUtil.IsGameSandbox() ? 
                (RePlugin.TryGetPartRecord(Part.PartData.partName, true) - 0.2 + Modifier) * 100 : Modifier * 125;
            if (DataDmg.records == null)
                DataDmg.records = new Dictionary<string, double> { ["Engineering_Age"] = 0 };
            CheckFailPoint();
        }

        public override void OnUpdate(double universalTime, double deltaUniversalTime) {
            if (Part?.IsDestroyedOrBeingDestroyed ?? true) return;
            if (GetDamage() > 100) {
                // if (RePlugin.destroyableParts?.Value ?? false) {
                if ((Part.ParentPart?.TryGetModule(out PartComponentModule_DamageEngine moduleDmgEng) ?? false) && moduleDmgEng != null)
                    moduleDmgEng.AddDamage(Part.ExplosionPotential * UnityEngine.Random.Range(15, 35), "Flight_Impacts");
                else if ((Part.ParentPart?.TryGetModule(out PartComponentModule_Damage moduleDmg) ?? false) && moduleDmg != null)
                    moduleDmg.AddDamage(Part.ExplosionPotential * UnityEngine.Random.Range(15, 35), "Flight_Impacts");
                Part.DestroyPart(ExplosionType.Default);
                // } else SetDamage(85.01);
                return;
            } else if (GetDamage() < 85 && universalTime > (lastDailyUpdateUT + 21600)) {
                OnDailyUpdate(universalTime - lastDailyUpdateUT);
                lastDailyUpdateUT = universalTime;
            }

            //if (universalTime > (lastDailyUpdateUT + 2)) {
            //    OnSlowUpdate(universalTime - lastSlowUpdateUT);
            //    lastSlowUpdateUT = universalTime;
            //}
            // if (!Part.SimulationObject.Telemetry.IsInAtmosphere) return;
        }

        protected virtual void OnSlowUpdate(double fixedDeltaT) {
        
        }
        protected virtual void OnDailyUpdate(double deltaT) {
            AddDamage(deltaT / 1080000d, "Engineering_Age");
            CheckFailPoint();
            bool isBoiling = "0040-Methalox|0050-Methane|0060-Monopropellant|0065-Nose Cone".Contains(Part.PartData.family);
            if (isBoiling) isBoiling = Part.PartResourceContainer.GetResourceStoredMass(RePlugin.fuelList.Last()) > 0;
            if (isLeaking || isBoiling)
                DrainResource(deltaT / 21600);
        }
        internal void AddDamage(double damage, string dmgType = null) {
            DataDmg.damage += damage;
            if (dmgType != null) AddRecords(damage, dmgType);
        }
        internal void SetDamage(double damage) => DataDmg.damage = damage;
        internal double GetDamage(bool mod = true) => DataDmg.damage * (mod ? 0.75 + Modifier * 0.5 : 1);

        internal void AddRecords(double amount, string type) {
            if (DataDmg.records.ContainsKey(type))
                DataDmg.records[type] += amount;
            else DataDmg.records[type] = amount;
        }

        private void CheckFailPoint() {
            if (RePlugin.repairers.Any(r => r.TargetGuid == Part.Guid)) return;
            // double failPoint = Modifier * 125;
            if (ReUtil.IsPALActive(Part.SimulationObject.Vessel, 9) && Math.Abs(FailPoint - GetDamage() - 1) < 0.07) {
                SetDamage(FailPoint - 0.9);
                Game.UniverseModel.SetTimePaused(true);
                PushNotify("/FaultDetected");
            } else if (Math.Abs(FailPoint - GetDamage()) < 0.07 || (GetDamage() < 1 && FailPoint < 1)) {
                ApplyFault();
                if (GetDamage() > 100) return;
                if (RePlugin.fuelList.All(r => !Part.PartResourceContainer.IsResourceContained(r))) return;
                isLeaking = true;
            }
        }
        internal void ApplyFault() {
            UnityEngine.Random.InitState(Part.Guid.GetHashCode() + Game.SessionGuidString.GetHashCode());
            AddDamage(15 + UnityEngine.Random.value * 100 * (1 - RePlugin.TryGetPartRecord(Part.PartData.partName, true) * 0.5), "Engineering_Faults");
        }

        private void DrainResource(double deltaT) {
            if (Part.PartResourceContainer.GetStoredResourcesTotalMass() < 0.01) return;
            ResourceDefinitionID resID = RePlugin.fuelList.FirstOrDefault(r => Part.PartResourceContainer.GetResourceStoredUnits(r) > 0);
            double resUnits = Part.PartOwner.ContainerGroup.GetResourceStoredUnits(resID);
            double unitsToRemove = resUnits * (isLeaking ? 0.0005 * GetDamage() : Math.Max(0, Part.ThermalData.Temperature - 50) / 30000) * deltaT;
            Part.PartOwner.ContainerGroup.RemoveResourceUnits(resID, unitsToRemove);
            if (!isLeaking) AddRecords((unitsToRemove / resUnits) * 100, "Flight_Boiloff");
        }

        internal void PushNotify(string locKey) {
            NotificationData notify = new NotificationData { Tier = NotificationTier.Alert, TimeStamp = Game.UniverseModel.UniverseTime,
                Importance = "/Heavy|Engine/IgnitionFailed".Contains(locKey) ? NotificationImportance.High :
                    "/Medium|/FaultDetected".Contains(locKey) ? NotificationImportance.Medium : NotificationImportance.Low
            };
            notify.AlertTitle.LocKey = "PartModules/Damage" + locKey;
            if (locKey == "/FaultDetected") notify.AlertTitle.ObjectParams = new object[1] { Part?.PartOwner?.SimulationObject?.Vessel?.DisplayName };
            bool showName = "/Repaired|Engine/IgnitionFailed".Contains(locKey);
            notify.FirstLine.LocKey = showName ? $"Parts/Title/{Part?.DisplayName}" : "PartModules/Damage/Serial";
            if (!showName) notify.FirstLine.ObjectParams = new object[1] { Part?.Guid.Substring(24) };
            Game.Notifications.ProcessNotification(notify);
        }

    }


    [Serializable]
    public class Data_DamageEngine : Data_Damage {

        [LocalizedField("PartModules/DamageEngine/UnlockThrottle")]
        [PAMDisplayControl(SortIndex = 4)]
        [KSPState(CopyToSymmetrySet = true)]
        [HideInInspector]
        public ModuleProperty<bool> toggleUnlockThrot = new ModuleProperty<bool>(false);

        public override Type ModuleType => typeof(Module_DamageEngine);

    }

    [DisallowMultipleComponent]
    public class Module_DamageEngine : Module_Damage {

        [SerializeField]
        protected Data_DamageEngine dataDamageEngine;
        protected Module_Engine moduleEngine;
        protected Data_Engine dataEngine;
        protected ModuleProperty<bool> toggleOverThrot;
        protected float maxThrust;
        protected float minThrust;
        private bool isIgnited;
        private bool reduceDmg;
        private int fuelStarvedTicks;
        private string engTypeKey;

        public override Type PartComponentModuleType => typeof(PartComponentModule_DamageEngine);
        public override Data_Damage DataDmg => dataDamageEngine;
        public virtual Data_DamageEngine DataDmgEng => dataDamageEngine;
        public override PartComponentModule_Damage CompModuleDmg => ComponentModule as PartComponentModule_Damage;

        protected override void AddDataModules() => DataModules.TryAddUnique(dataDamageEngine, out dataDamageEngine);
        protected override void OnInitialize() {
            base.OnInitialize();
            DataDmgEng.toggleUnlockThrot.OnChangedValue += OnToggleUnlockThrot;
            toggleOverThrot = new ModuleProperty<bool>(false);
            string overThrotLabel = "PartModules/DamageEngine/Overthrottle";
            toggleOverThrot.ContextKey = overThrotLabel;
            DataDmgEng.AddProperty(overThrotLabel, toggleOverThrot);
            DataDmgEng.SetSortIndex(toggleOverThrot, 4);
            toggleOverThrot.OnChangedValue += OnToggleOverThrot;
            ResetEngSetup();
        }
        protected override void OnStart() {
            base.OnStart();
            TryGetComponent(out moduleEngine);
            moduleEngine.DataModules.TryGetByType(out dataEngine);
            if (PartBackingMode == PartBackingModes.Flight)
                engTypeKey = $"{(part?.SimObjectComponent?.PartData?.family == "0120-Jet Engine" ? "Aeronautics" : "Propulsion")}_{part?.SimObjectComponent?.PartData?.family?.Substring(5).Replace(" ", "")}";
            ResetEngSetup();
        }
        protected override void OnShutdown() {
            if (DataDmgEng?.toggleUnlockThrot != null)
                DataDmgEng.toggleUnlockThrot.OnChangedValue -= OnToggleUnlockThrot;
            if (toggleOverThrot != null)
                toggleOverThrot.OnChangedValue -= OnToggleOverThrot;
        }
        protected override void OnModuleFixedUpdate(float fixedDeltaTime) {
            if (dataEngine?.CurrentPropellantState?.pendingRequest ?? false) {
                fuelStarvedTicks = 0;
                if (!isIgnited) OnIgnition();
                if (toggleOverThrot.GetValue())
                    CompModuleDmg.AddDamage(fixedDeltaTime * 3, engTypeKey);
                if (DataDmgEng.toggleUnlockThrot.GetValue() && !reduceDmg)
                    if (moduleEngine.throttleSetting < MinSafeThrotPct)
                        CompModuleDmg.AddDamage(fixedDeltaTime * 20 * (MinSafeThrotPct - moduleEngine.throttleSetting), engTypeKey);
                CompModuleDmg.AddDamage(fixedDeltaTime * (CompModuleDmg.GetDamage() > 85 ? 0.7 : 0.1) * (reduceDmg ? 0.25 : 1), engTypeKey);
                //if (CompModuleDmg.GetDamage() > 85)
                //    CompModuleDmg.AddDamage(fixedDeltaTime * 0.7 * (reduceDmg ? 0.25 : 1), engTypeKey);
            } else if (fuelStarvedTicks < 7)
                fuelStarvedTicks++;
            else isIgnited = false;
            base.OnModuleFixedUpdate(fixedDeltaTime);
        }

        public float MinSafeThrotPct => minThrust / maxThrust;

        protected override void OnModuleSlowUpdate(double deltaT) {
            if (lastSlowUpdateDmg != 0 && lastSlowUpdateDmg < CompModuleDmg.FailPoint && CompModuleDmg.GetDamage() > CompModuleDmg.FailPoint)
                CompModuleDmg.ApplyFault();
            base.OnModuleSlowUpdate(deltaT);
            if (dataEngine?.engineModes.Count() > 1)
                ResetEngSetup();
            if (RePlugin.UIPart?.Guid == part.SimObjectComponent.Guid)
                RePlugin.UIEngInstability = toggleOverThrot.GetValue() ? 0.15 : DataDmgEng.toggleUnlockThrot.GetValue() ? Mathf.Clamp01(MinSafeThrotPct - moduleEngine.throttleSetting) : 0.0;
        }
        
        private void OnIgnition() {
            isIgnited = true;
            bool isSRB = moduleEngine.currentEngineModeData.engineType == EngineType.SolidBooster;
            if (reduceDmg && !isSRB) return;
            double gForce = vessel.SimObjectComponent.geeForce;
            int rand = UnityEngine.Random.Range(0, moduleEngine?.currentEngineModeData?.propellant?.mixtureName == "Hydrolox" ? 38 : 37);
            if (!isSRB && rand > Math.Min(gForce * 1000, 35) - CompModuleDmg.GetDamage() * 0.3) {
                moduleEngine.DeactivateEngine();
                CompModuleDmg.PushNotify("Engine/IgnitionFailed");
            }
            CompModuleDmg.AddDamage(isSRB ? 20 + rand * 0.5 : Math.Max(10.01, rand * 15 * (0.1 - Math.Min(gForce, 0.035))), engTypeKey);
            if (gForce < 0.035) CompModuleDmg.AddRecords((0.035 - gForce) * 100, "Flight_Ullage");
        }
        
        protected void OnToggleOverThrot(bool isToggleOn) {
            if (isToggleOn) {
                if (DataDmgEng?.toggleUnlockThrot.GetValue() ?? false) {
                    OnToggleUnlockThrot(false);
                    DataDmgEng?.toggleUnlockThrot.SetValue(false);
                } else TryStoreThrust();
                moduleEngine.currentEngineModeData.maxThrust *= 1.1f;
                moduleEngine.currentEngineModeData.minThrust = moduleEngine.currentEngineModeData.maxThrust;
            } else RestoreDefaultThrust();
            dataEngine.SetConsumptionRate();
        }
        protected void OnToggleUnlockThrot(bool isToggleOn) {
            if (isToggleOn) {
                if (toggleOverThrot?.GetValue() ?? false) {
                    OnToggleOverThrot(false);
                    toggleOverThrot?.SetValue(false);
                } else TryStoreThrust();
                moduleEngine.currentEngineModeData.minThrust = 0;
            } else RestoreDefaultThrust();
            dataEngine.SetConsumptionRate();
        }

        protected void ResetEngSetup() {
            reduceDmg = !"Methalox|Hydrolox|Hydrogen|SolidFuel".Contains(moduleEngine?.currentEngineModeData?.propellant?.mixtureName ?? "-");
            DataDmgEng?.SetVisible(DataDmgEng.toggleUnlockThrot, !"MonoPropellant|SolidFuel|MethaneAir|HydrogenAir".Contains(moduleEngine?.currentEngineModeData?.propellant?.mixtureName ?? "-"));
            DataDmgEng?.SetVisible(toggleOverThrot, moduleEngine?.currentEngineModeData?.propellant?.mixtureName == "Methalox");
        }
        private void TryStoreThrust() {
            maxThrust = moduleEngine.currentEngineModeData.maxThrust;
            if (moduleEngine.currentEngineModeData.minThrust > 0)
                minThrust = moduleEngine.currentEngineModeData.minThrust;
        }
        private void RestoreDefaultThrust() {
            moduleEngine.currentEngineModeData.maxThrust = maxThrust;
            moduleEngine.currentEngineModeData.minThrust = minThrust;
        }

    }

    public class PartComponentModule_DamageEngine : PartComponentModule_Damage {

        private Data_DamageEngine dataDamageEngine;

        public override Type PartBehaviourModuleType => typeof(Module_DamageEngine);
        public override Data_Damage DataDmg => dataDamageEngine;

        public override void OnStart(double universalTime) {
            DataModules.TryGetByType(out dataDamageEngine);
            base.OnStart(universalTime);
        }

    }


    [Serializable]
    public class Data_DamageEVA : ModuleData {

        public override Type ModuleType => typeof(Module_DamageEVA);

    }

    [DisallowMultipleComponent]
    public class Module_DamageEVA : PartBehaviourModule {

        [SerializeField]
        protected Data_DamageEVA dataDamageEVA;
        private double lastSlowUpdateUT;
        private float updateDeltaT;

        public override Type PartComponentModuleType => typeof(PartComponentModule_DamageEVA);
        public virtual PartComponentModule_DamageEVA CompModuleDmg => ComponentModule as PartComponentModule_DamageEVA;

        protected override void AddDataModules() => DataModules.TryAddUnique(dataDamageEVA, out dataDamageEVA);
        protected override void OnInitialize() {
            lastSlowUpdateUT = Game.UniverseModel.UniverseTime;
            updateDeltaT = (float)CompModuleDmg?.Modifier;
            
        }
        protected override void OnStart() {
            
        }
        protected override void OnModuleUpdate(float deltaTime) {
            updateDeltaT += deltaTime;
            if (updateDeltaT > 1) {
                OnModuleSlowUpdate(Game.UniverseModel.UniverseTime - lastSlowUpdateUT);
                lastSlowUpdateUT = Game.UniverseModel.UniverseTime;
                updateDeltaT = 0;
            }
        }
        protected override void OnModuleFixedUpdate(float fixedDeltaTime) {
            if (part?.IsSimObjectDestroyed() ?? true) return;
            //double heatDmgThreshold = part.SimObjectComponent.PartData.maxTemp * 0.6;
            //if (part.SimObjectComponent.ThermalData.Temperature > heatDmgThreshold) {
            //    double dmg = fixedDeltaTime * (Math.Pow(1.047, ((part.SimObjectComponent.ThermalData.Temperature - heatDmgThreshold) / (part.SimObjectComponent.PartData.maxTemp - heatDmgThreshold)) * 75) - 1);
            //    CompModuleDmg.AddDamage(dmg, "Wounded_Heat");
            //}
        }

        protected virtual void OnModuleSlowUpdate(double fixedDeltaT) {
            if (RePlugin.UIPart?.Guid == part.SimObjectComponent.Guid) {
                if (RePlugin.inspectTicks == -1)
                    RePlugin.inspectTicks = 7;
                RePlugin.UIPartDmg = CompModuleDmg.GetDamage("Lonely");
            }
            if (RePlugin.repairers.Count == 0) return;
            if (!RePlugin.repairers.Any(r => r.TargetGuid == part.SimObjectComponent.Guid)) return;
            
        }

    }

    public class PartComponentModule_DamageEVA : PartComponentModule {

        private Data_DamageEVA dataDamageEVA;
        // private KerbalDamage kerbalDamage;
        internal double Modifier { get; private set; }
        internal double FailPoint { get; private set; }

        public override Type PartBehaviourModuleType => typeof(Module_DamageEVA);

        public override void OnStart(double universalTime) {
            DataModules.TryGetByType(out dataDamageEVA);
            UnityEngine.Random.InitState(Part.Guid.GetHashCode());
            Modifier = UnityEngine.Random.value;
            FailPoint = Modifier * 125;
            // kerbalLife = ReUtil.GetKerbalLife(Game.SessionManager.KerbalRosterManager.GetAllKerbalsInSimObject(Part.GlobalId).First().NameKey);
        }

        public override void OnUpdate(double universalTime, double deltaUniversalTime) {
            if (Part?.IsDestroyedOrBeingDestroyed ?? true) return;
            //if (GetDamageTotal() > 100) {

            //    Part.DestroyPart(ExplosionType.Default);
            //    return;
            //}
            

        }

        protected virtual void OnSlowUpdate(double fixedDeltaT) {
            // add fatigue - general
        }

        // internal void AddDamage(double damage, string dmgType) => kerbalDamage.AddDamage(dmgType, damage);

        internal double GetDamage(string type, bool mod = true) => 0; // kerbalLife.GetDamage(type);
        internal double GetDamageTotal(bool mod = true) => 0; // kerbalLife.TotalDamage();

    }



}

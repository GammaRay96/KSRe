﻿using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using I2.Loc;
using KSP;
using KSP.Game;
using KSP.Game.Science;
using KSP.Messages;
using KSP.OAB;
using KSP.Sim;
using KSP.Sim.impl;
using KSP.Sim.ResourceSystem;
using Newtonsoft.Json;
using SpaceWarp;
using SpaceWarp.API.Assets;
using SpaceWarp.API.Mods;
using SpaceWarp.API.Game.Messages;
using SpaceWarp.API.SaveGameManager;
using SpaceWarp.API.UI;
using SpaceWarp.API.UI.Appbar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using TMPro;
using System.Data;
using System.IO;

namespace KSRe {

    [BepInPlugin("KSRe", "KSRe", VERSION)]
    [BepInDependency(SpaceWarpPlugin.ModGuid, SpaceWarpPlugin.ModVer)]
    public class RePlugin : BaseSpaceWarpPlugin {

        public const string VERSION = "0.24.9";
        
        internal static new ManualLogSource Logger;

        // public ConfigEntry<bool> techDiscovery;
        public static ConfigEntry<bool> fuelRatiosByVol;
        // public static ConfigEntry<bool> destroyableParts;
        public static ConfigEntry<KeyCode> repairKeyCode;
        public static ConfigEntry<KeyCode> appKeyCode;

        private ResourceContainerChangedMessage lastResMsg;
        private ushort fuelContIDVal;
        internal static List<ResourceDefinitionID> fuelList;
        internal static ReSaveData saveData;
        private GUIStyle UIStyle, btnStyle, btnXStyle, btnLStyle, btnRStyle, btnKStyle, btnMStyle;
        private Color UIBgColor;
        private Texture2D UIAppTex;
        private Rect UIRect;
        private bool inGame, showUI, minUI, diagMode, showApp, lockUI;
        private float slowUpdateDeltaT;
        private double lastSlowUpdateUT;
        private GUIData guiData;
        internal static int inspectTicks;
        internal static double UIPartDmg, UIEngInstability;
        internal static Tuple<float, float> UIPartImpacts;
        private string prevCelTransNames;
        private VesselComponent activeVessel;
        internal static PartComponent UIPart;
        internal static List<Repairer> repairers;

        public void Awake() {
            Harmony.CreateAndPatchAll(typeof(RePlugin).Assembly);
            Logger = base.Logger;
            // techDiscovery = Config.Bind("Campaign", "Tech Discovery", true, "Whether technologies are discovered gradually in the tree");
            fuelRatiosByVol = Config.Bind("General", "Show Fuel Ratios by Volume", true, "Whether to display engine fuel ratios by volume (instead of mass)");
            // destroyableParts = Config.Bind("General", "Ruined Parts are Destroyable", true, "Whether ruined parts may be destroyed from further damage");
            repairKeyCode = Config.Bind("General", "Repair Key", KeyCode.G, "Key to start repairing a damaged part");
            appKeyCode = Config.Bind("General", "R&D App Key", KeyCode.C, "Key to display Kerbal Life App in R&D / Tracking Station");
            // techDiscovery.SettingChanged += delegate { if (Game?.GlobalGameState.GetGameState().GameState == GameState.ResearchAndDevelopment) UpdateTechDiscovery(); };
            StateChanges.ResearchAndDevelopmentEntered += EnteredRnD;
            UIBgColor = new Color(0, 0, 0, 1);
            UIAppTex = new Texture2D(1, 1, TextureFormat.RGBAFloat, false);
            UIAppTex.SetPixel(0, 0, new Color(1, 1, 1, 0.95f));
            UIAppTex.Apply();
            UIRect = new Rect((Screen.width * 0.71f) - (360 / 2), Screen.height * 0.25f, 0, 0); // - 92
            repairers = new List<Repairer>();
            diagMode = true;
            prevCelTransNames = "-";
            UIPartImpacts = Tuple.Create(0f, 0f);
            string dataPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "data");
            StartCoroutine(CallbackUtil.DelayedCallback(1, delegate {
                ReUtil.dmgSciRates = JsonConvert.DeserializeObject<Dictionary<string, float>>(File.ReadAllText(Path.Combine(dataPath, "dmg_sci_rates.json"))); }));
            StartCoroutine(CallbackUtil.DelayedCallback(2, delegate {
                ReUtil.careerSpecTechs = JsonConvert.DeserializeObject<Dictionary<string, string[]>>(File.ReadAllText(Path.Combine(dataPath, "sci_types_tech_prereqs.json"))); }));
            StartCoroutine(CallbackUtil.DelayedCallback(3, delegate {
                ReUtil.sciLvls = JsonConvert.DeserializeObject<Dictionary<int, float>>(File.ReadAllText(Path.Combine(dataPath, "sci_lvls_buffs.json"))); }));
            StartCoroutine(CallbackUtil.DelayedCallback(4, delegate {
                ReUtil.mfParts = JsonConvert.DeserializeObject<Dictionary<string, string[]>>(File.ReadAllText(Path.Combine(dataPath, "part_mfr_agencies.json"))); }));
            StartCoroutine(CallbackUtil.DelayedCallback(5, delegate {
                ReUtil.partKerbStats = JsonConvert.DeserializeObject<Dictionary<string, string[]>>(File.ReadAllText(Path.Combine(dataPath, "part_kerb_statuses.json"))); }));
            StartCoroutine(CallbackUtil.DelayedCallback(6, delegate {
                ReUtil.crewAgencies = JsonConvert.DeserializeObject<Dictionary<string, string[]>>(File.ReadAllText(Path.Combine(dataPath, "crew_agencies.json")));
            }));
        }

        public override void OnInitialized() {
            Game.Messages.PersistentSubscribe<GameStateChangedMessage>(ChangedGameState);
            Game.Messages.PersistentSubscribe<UISliderReleasedMessage>(ReleasedUISlider);
            Game.Messages.PersistentSubscribe<ResourceContainerChangedMessage>(ChangedResCont);
            // game.Messages.PersistentSubscribe<PartPlacedMessage>(PlacedPart);
            Game.Messages.PersistentSubscribe<PartSeparatedMessage>(SeparatedPart);
            Game.Messages.PersistentSubscribe<PartBehaviourInitializedMessage>(PartBehaviourInitialized);
            // Game.Messages.PersistentSubscribe<VABSymmetryModeChangedMessage>(ChangedSymmetryMode);
            Game.Messages.PersistentSubscribe<VesselChangedMessage>(ChangedVessel);
            Game.Messages.PersistentSubscribe<PartUnderMouseChanged>(ChangedMousePart);
            Game.Messages.PersistentSubscribe<VesselCreatedMessage>(CreatedVessel);
            Game.Messages.PersistentSubscribe<SOIEnteredMessage>(EnteredSOI);
            Game.Messages.PersistentSubscribe<ResearchReportScoredMessage>(ScoredResearchReport);
            Game.Messages.PersistentSubscribe<VesselRecoveredMessage>(RecoveredVessel);
            // Game.Messages.PersistentSubscribe<MissionCompleteMessage>(CompletedMission);
            Game.Messages.PersistentSubscribe<SciencePointCapacityUpdateMessage>(UpdatedSciencePoints);
            Game.Messages.PersistentSubscribe<KerbalAddedToRoster>(AddedNewKerbal);
            Game.Messages.PersistentSubscribe<KerbalRemovedFromRoster>(RemovedKerbal);
            Game.Messages.PersistentSubscribe<KerbalLocationChanged>(MovedKerbal);
            Appbar.RegisterAppButton(LocalizationManager.GetTranslation("Diagnostic/Title"), "BTN-ReDiagnostic", AssetManager.GetAsset<Texture2D>($"KSRe/images/icon2_w.png"), ToggleGUI);
            //Appbar.RegisterKSCAppButton(LocalizationManager.GetTranslation("Diagnostic/Title"), "BTN-ReDiagnostic", AssetManager.GetAsset<Texture2D>($"KSRe/images/icon2.png"), ToggleGUI);
            //Appbar.RegisterOABAppButton(LocalizationManager.GetTranslation("Diagnostic/Title"), "BTN-ReDiagnostic", AssetManager.GetAsset<Texture2D>($"KSRe/images/icon2_w.png"), ToggleGUI);
            Appbar.RegisterAppButton(LocalizationManager.GetTranslation("KerbalLife/Title"), "BTN-KerbalLife", AssetManager.GetAsset<Texture2D>($"KSRe/images/icon_w.png"), ToggleApp);
            Appbar.RegisterKSCAppButton(LocalizationManager.GetTranslation("KerbalLife/Title"), "BTN-KerbalLife", AssetManager.GetAsset<Texture2D>($"KSRe/images/icon.png"), ToggleApp);
            Appbar.RegisterOABAppButton(LocalizationManager.GetTranslation("KerbalLife/Title"), "BTN-KerbalLife", AssetManager.GetAsset<Texture2D>($"KSRe/images/icon_w.png"), ToggleApp);
            UIStyle = new GUIStyle(Skins.ConsoleSkin.window) { padding = new RectOffset(8, 8, 8, 8), contentOffset = new Vector2(0, -5), fixedWidth = 360 };
            UIStyle.normal.background = UIAppTex;
            btnStyle = new GUIStyle(Skins.ConsoleSkin.button);
            btnXStyle = new GUIStyle(Skins.ConsoleSkin.button);
            btnLStyle = new GUIStyle(Skins.ConsoleSkin.button);
            btnRStyle = new GUIStyle(Skins.ConsoleSkin.button);
            btnKStyle = new GUIStyle(Skins.ConsoleSkin.button);
            btnMStyle = new GUIStyle(Skins.ConsoleSkin.button);
            btnStyle.normal.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/btnNorm.png");
            btnStyle.hover.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/btnHover.png");
            btnStyle.active.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/btnActive.png");
            btnStyle.onNormal.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/btnActive.png");
            btnStyle.onActive.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/btnActive.png");
            btnStyle.onHover.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/btnHover.png");
            btnXStyle.normal.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/btnNorm.png");
            btnXStyle.hover.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/btnXHover.png");
            btnXStyle.active.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/btnXActive.png");
            btnLStyle.normal.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/btnLNorm.png");
            btnLStyle.hover.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/btnLHover.png");
            btnLStyle.active.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/btnLActive.png");
            btnRStyle.normal.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/btnRNorm.png");
            btnRStyle.hover.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/btnRHover.png");
            btnRStyle.active.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/btnRActive.png");
            btnKStyle.normal.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/icon.png");
            btnKStyle.hover.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/icon_h.png");
            btnKStyle.active.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/icon_h.png");
            btnMStyle.normal.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/icon3.png");
            btnMStyle.hover.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/icon3_h.png");
            btnMStyle.active.background = AssetManager.GetAsset<Texture2D>($"KSRe/images/icon3_h.png");
            saveData = ModSaves.RegisterSaveLoadGameData("KSRe", null, null, saveData);
            ReUtil.agencyFlags = new Dictionary<string, Texture2D>();
            Dictionary<string, string> flags = new Dictionary<string, string>() {
                ["KSC"] = "flag_AGY_Default",
                ["BobsGirders"] = "flag_MFG_Bobs.png",
                ["1Proton"] = "flag_MFG_1Proton.png",
                ["HyperShovel"] = "flag_MFG_Hyper.png",
                ["JoelsLenses"] = "flag_MFG_Joel.png",
                ["Kitbashi"] = "flag_MFG_Kitbashi.png",
                ["MajorComms"] = "flag_MFG_Major.png",
                ["C7"] = "flag_MFG_C7.png",
                ["Ionic"] = "flag_MFG_Ionic.png",
                ["JebsJunkyard"] = "flag_MFG_Jebediah.png",
                ["Kerbodyne"] = "flag_MFG_Kerbodyne_v2.png",
                ["Lightyear"] = "flag_MFG_LightYear.png",
                ["Periapsis"] = "flag_MFG_Periapsis.png",
                ["ReactionSystems"] = "flag_MFG_Reaction.png",
                ["Rockomax"] = "flag_MFG_Rockomax.png",
                ["STEADLER"] = "flag_MFG_STEADLER_v2.png",
            };
            Dictionary<string, string> flagsExt = new Dictionary<string, string>() {
                ["KerbalMotion"] = "flag_KerbalMotion.png",
            };
            foreach (var pair in flags)
                GameManager.Instance.Assets.Load<Texture2D>(pair.Value, t => { ReUtil.agencyFlags[pair.Key] = t; });
            foreach (var pair in flagsExt)
                ReUtil.agencyFlags[pair.Key] = AssetManager.GetAsset<Texture2D>($"KSRe/images/{pair.Value}");
            // GameManager.Instance.Assets.Load<Texture2D>("flag_MFG_Reaction.png", tex => { testAsset = tex; });
        }

        private void OnGUI() {
            if (!showUI && !showApp) return;
            GUI.skin = Skins.ConsoleSkin;
            if (showUI) GUI.backgroundColor = UIBgColor;
            UIRect = showUI ? GUILayout.Window(GUIUtility.GetControlID(FocusType.Passive), UIRect, GUIContent, guiData.WindowTitle, UIStyle, GUILayout.Height(0)) :
                GUILayout.Window(GUIUtility.GetControlID(FocusType.Passive), UIRect, AppContent, guiData.AppTitle, UIStyle, GUILayout.Height(0));
        }
        public void Update() {
            if (!inGame) return;
            slowUpdateDeltaT += Time.deltaTime;
            if (slowUpdateDeltaT > 1) SlowUpdate();
            GameState? gameState = Game?.GlobalGameState?.GetGameState()?.GameState;
            if ((gameState == GameState.ResearchAndDevelopment || gameState == GameState.MissionControl) && Input.GetKeyDown(appKeyCode.Value)) ToggleApp();
            if (gameState != GameState.FlightView) return;
            if (showUI && (activeVessel?.IsKerbalEVA ?? false) && UIPart != null && diagMode && Input.GetKeyDown(repairKeyCode.Value) && inspectTicks == 0) {
                if (UIPart.PartOwner.SimulationObject.Vessel.IsKerbalEVA) {
                    lockUI = !lockUI;
                    ReUtil.PushNotify(UIPart.PartOwner.SimulationObject.Vessel.DisplayName, lockUI ? "Hello" : "Bye", NotificationImportance.Low);
                } else if (!repairers.Any(r => r.Guid == activeVessel.Guid) &&
                    UIPart.PartOwner.SimulationObject.Vessel.SimulationObject.Telemetry.CommNetConnectionStatus == ConnectionNodeStatus.Connected) {
                    // lockUI = true;
                    repairers.Add(new Repairer(activeVessel.DisplayName, activeVessel.Guid, UIPart.Guid));
                    guiData.UpdateEVARepairers();
                }
            }
            if (!Game?.ResourceManager?.IsVisible ?? false) return;
            foreach (PartComponent part in Game?.ViewController?.GetActiveVehicle()?.GetSimVessel()?.SimulationObject.PartOwner.Parts) {
                if (part == null) continue;
                ResourceContainer resCont = part.PartResourceContainer;
                if (resCont == null) continue;
                if (resCont.GetResourcesContainedCount() == 0 || part.PartResourceContainer.GetStoredResourcesTotalMass() == 0) continue;
                if (!fuelList.All(f => resCont.IsResourceContained(f))) continue;
                if (fuelList.Where(r => resCont.GetResourceStoredMass(r) > 0).Count() > 1)
                    resCont.DumpAllResources();
            }
        }
        private void SlowUpdate() {
            slowUpdateDeltaT = 0;
            // if (saveData.modVersion != VERSION) InitOrUpdateSave();
            if (lastSlowUpdateUT == 0)
                lastSlowUpdateUT = Game.UniverseModel.UniverseTime;
            else SlowUpdateKerbalDamage(Game.UniverseModel.UniverseTime - lastSlowUpdateUT);
            if (showApp && !ReUtil.IsGameSandbox() && ReUtil.IsPlayerAgency(guiData.Agency)) {
                guiData.UpdateDiscovery();
                guiData.UpdateSciLevel();
            }
            if (Game.UniverseModel.UniverseTime > saveData.lastDailyUpdateUT + 21600) {
                DailyUpdate(Game.UniverseModel.UniverseTime - saveData.lastDailyUpdateUT);
                saveData.lastDailyUpdateUT = Math.Round(Game.UniverseModel.UniverseTime);
            }
            if (!showUI) return;
            if (activeVessel == null || (UIPart?.IsDestroyedOrBeingDestroyed ?? false))
                UpdateGUIVessel();
            if (!diagMode) guiData.UpdateListMode();
            else if (UIPart != null) {
                if (activeVessel?.IsKerbalEVA ?? false) {
                    if (Position.Distance(activeVessel.transform.Position, UIPart.transform.Position) > UIPart.PartData.PartSizeDiameter + 1.5) {
                        UIPart = null;
                        inspectTicks = -1;
                    } else {
                        guiData.UpdateEVADamage();
                        if (inspectTicks > 0) inspectTicks--;
                    }
                    guiData.UpdateEVARepairers();
                } else if (!(activeVessel?.IsKerbalEVA ?? true))
                    guiData.UpdateForVessel(ReUtil.IsPALActive(UIPart?.PartOwner?.SimulationObject?.Vessel));
            }
        }
        private void DailyUpdate(double deltaT) {
            double oneDayRate = deltaT / 21600;
            foreach (KerbalDamage kerbd in saveData.kerbals) {
                if (kerbd.status.StartsWith("KSC")) {
                    // UnityEngine.Random.InitState((kerbd.Name + kerbd.Trait + "Psychology_Therapy").GetHashCode());
                    // kerbd.status = "KSC STANDBY";
                    double impactDmg = TryGetKerbalDamage(kerbd, "Medicine_Impacts");
                    UnityEngine.Random.InitState((kerbd.Name + kerbd.Trait + "Medicine_Impacts").GetHashCode());
                    if (impactDmg > UnityEngine.Random.value * 5) {
                        AddKerbalDamage(kerbd, "Medicine_Impacts", -oneDayRate * 0.25);
                        kerbd.status = "KSC MED BAY";
                        continue;
                    } else if (kerbd.status == "KSC MED BAY") {
                        KerbalLifeRewards("Medicine_Impacts", force: true);
                        kerbd.status = "KSC STANDBY";
                        ReUtil.PushNotify(kerbd.Name, "Recovery/Impacts", NotificationImportance.Low, false);
                        continue;
                    }
                    double atrophyDmg = TryGetKerbalDamage(kerbd, "Medicine_Atrophy");
                    if (atrophyDmg > 0) {
                        AddKerbalDamage(kerbd, "Medicine_Atrophy", -oneDayRate * 0.5);
                        kerbd.status = "KSC RECOVERY";
                        continue;
                    } else if (kerbd.status == "KSC RECOVERY") {
                        KerbalLifeRewards("Medicine_Atrophy", force: true);
                        kerbd.status = "KSC STANDBY";
                        ReUtil.PushNotify(kerbd.Name, "Recovery/Atrophy", NotificationImportance.Low, false);
                        continue;
                    }
                    double socialDmg = TryGetKerbalDamage(kerbd, "Psychology_Social");
                    if (socialDmg > 25 && Math.Abs(TryGetKerbalDamage(kerbd, "Psychology_Therapy")) < socialDmg) {
                        AddKerbalDamage(kerbd, "Psychology_Therapy", -oneDayRate);
                        kerbd.status = "KSC THERAPY";
                        continue;
                    } else if (kerbd.status == "KSC THERAPY") {
                        KerbalLifeRewards("Psychology_Therapy", force:true);
                        kerbd.status = "KSC STANDBY";
                        ReUtil.PushNotify(kerbd.Name, "Recovery/Therapy", NotificationImportance.Low, false);
                        continue;
                    }
                    UnityEngine.Random.InitState((kerbd.Name + kerbd.Trait + "Medicine_Atrophy").GetHashCode());
                    if (atrophyDmg > UnityEngine.Random.value * -10) {
                        AddKerbalDamage(kerbd, "Medicine_Atrophy", -oneDayRate * 0.5);
                        kerbd.status = "KSC FITNESS";
                        continue;
                    }
                } else {
                    Game.SessionManager.KerbalRosterManager.TryGetKerbalByName(kerbd.Name, out KerbalInfo kerbi);
                    SimulationObjectModel simObj = Game.ViewController.Universe.FindSimObject(kerbi.Location.SimObjectId);
                    double geeForce = simObj?.Part?.PartOwner?.SimulationObject?.Vessel?.geeForce ?? 0;
                    if (TryGetKerbalDamage(kerbd, "Medicine_Atrophy") < (1 - Mathf.Clamp01((float)geeForce)) * 50)
                        AddKerbalDamage(kerbd, "Medicine_Atrophy", oneDayRate * (0.25 - geeForce));
                }
            }
        }

        private void LoadedData(ReSaveData data) {
            //if (Game.SessionManager.ActiveGameMode == "SandboxMode" || saveData?.agencies?.First()?.leaderTrait != null) return;
            //saveData.agencies.First().leaderTrait = ReUtil.careerSpecTechs.Keys.First();
            //saveData.agencies = new List<ReAgency>() { new ReAgency(Game.SessionManager.GetMyAgencyID().ToString()) };
        }

        private void ChangedGameState(MessageCenterMessage message) {
            GameStateChangedMessage msg = (GameStateChangedMessage)message;
            UnityEngine.Random.InitState(int.Parse($"{DateTime.Now.Minute}{DateTime.Now.Second}{DateTime.Now.Millisecond}"));
            inGame = msg?.CurrentState != GameState.MainMenu;
            // Logger.LogInfo(msg?.CurrentState);
            if (!((msg?.CurrentState == GameState.FlightView && msg?.PreviousState == GameState.Map3DView) ||
                (msg?.CurrentState == GameState.Map3DView && msg?.PreviousState == GameState.FlightView)))
                UIPart = null;
            showUI = false;
            showApp = false;
            repairers.Clear();
            if (guiData == null) guiData = new GUIData();
            if (!inGame) {
                saveData.agencies = null;
                saveData.kerbals = null;
                saveData.pals = null;
                saveData.modVersion = null;
                saveData.lastDailyUpdateUT = 0;
                guiData.Reset();
            } else if (saveData.modVersion != VERSION) InitOrUpdateSave();
            // else if ((saveData.agencies?.Count ?? 0) < 10) ReSetupGame();
            // else if (saveData.pals == null) saveData.pals = new Dictionary<Tuple<string, string>, double>();
            // if (msg?.CurrentState == GameState.KerbalSpaceCenter || msg?.CurrentState == GameState.MissionControl || msg?.CurrentState == GameState.ResearchAndDevelopment)
            //     TryUpdateRocketScienceHeaders();
            if (fuelContIDVal != 0) return;
            if (Game.ResourceDefinitionDatabase.GetAllResourceIDs().Count() == 0) return;
            // stock bug (v0.2.0): game.ResourceDefinitionDatabase.GetResourceIDFromName()
            ResourceDefinitionID recipeID = Game.ResourceDefinitionDatabase.GetAllResourceIDs().FirstOrDefault(r => Game.ResourceDefinitionDatabase.GetDefinitionData(r).name == "FuelContainer");
            if (recipeID.Value == 0) return;
            fuelContIDVal = recipeID.Value;
            fuelList = Game.ResourceDefinitionDatabase.GetDefinitionData(recipeID).recipeProperties.IngredientsResourceIDs.ToList();
            // cryoResIDVal = Game.ResourceDefinitionDatabase.GetAllResourceIDs().FirstOrDefault(r => Game.ResourceDefinitionDatabase.GetDefinitionData(r).name == "Hydrogen").Value;
        }

        private void PartBehaviourInitialized(MessageCenterMessage message) {
            PartBehaviourInitializedMessage msg = (PartBehaviourInitializedMessage)message;
            // Logger.LogInfo("init: " + msg.Part.SimObjectComponent.PartData.partName);
            if (msg.Part.SimObjectComponent.PartData.partName != "booster_1v_solid_flea") return;
            msg.Part.gameObject.transform.localScale = new Vector3(0.5f, 1, 0.5f);
        }
        private void PlacedPart(MessageCenterMessage message) {
            PartPlacedMessage msg = (PartPlacedMessage)message;
            if (msg.messagePart.PartName != "booster_1v_solid_flea") return;
            msg.messagePart.PartTransform.localScale = new Vector3(0.5f, 1, 0.5f);
        }
        private void SeparatedPart(MessageCenterMessage message) {
            PartSeparatedMessage msg = (PartSeparatedMessage)message;
            // Logger.LogInfo("sep: " + msg.messagePart.PartName);
            if (msg?.messagePart?.PartName != "booster_1v_solid_flea") return;
            msg.messagePart.PartTransform.localScale = new Vector3(0.5f, 1, 0.5f);
        }
        private void ChangedSymmetryMode(MessageCenterMessage message) {
            IObjectAssemblyPart part = Game?.OAB?.Current.Stats?.LastPartGrabbed;
            // Logger.LogInfo("sym: " + part?.PartName);
            // if (part?.PartName != "booster_1v_solid_flea") return;
            VABSymmetryModeChangedMessage msg = (VABSymmetryModeChangedMessage)message;
            // Logger.LogInfo("mode: " + (int)Game?.OAB?.Current?.Stats?.SymmetryMode.GetValue());
            if ((int)Game?.OAB?.Current?.Stats?.SymmetryMode.GetValue() < 2) return;
            Logger.LogInfo("symcount: " + part.SymmetrySet.Parts.Count);
            Logger.LogInfo("symfleacount: " + part.SymmetrySet.Parts.Count(p => p.PartName == "booster_1v_solid_flea"));
            // Logger.LogInfo("symparts: " + part.SymmetrySet.Visualizer.SingleCopyMap.Keys.Where(p => p.PartName == "booster_1v_solid_flea").ToList().Count);
            // part.SymmetrySet.Visualizer.SingleCopyMap.Keys.Where(p => p.PartName == "booster_1v_solid_flea").ToList().ForEach(p => p.PartTransform.localScale = new Vector3(0.5f, 1, 0.5f));
        }

        private void EnteredRnD(GameStateEnteredMessage message) {
            string rdScrollBarPath = "GameManager/Default Game Instance(Clone)/UI Manager(Clone)/Main Canvas/RDCenterUI(Clone)/Container/TechTree/ELE-Scrollbar-Horizontal";
            GameObject.Find(rdScrollBarPath)?.SetActive(false);
            string tierContPath = "GameManager/Default Game Instance(Clone)/UI Manager(Clone)/Main Canvas/RDCenterUI(Clone)/Container/TechTree/TierScroll/TierSelectionContainer";
            RectTransform tierContTrans = GameObject.Find(tierContPath)?.GetComponent<RectTransform>();
            if (transform != null) tierContTrans.sizeDelta = new Vector2(0, 28);
            for (int i = 0; i < tierContTrans.childCount; i++) {
                RectTransform t1 = tierContTrans.GetChild(i)?.FindChildRecursive("Text (TMP)")?.GetComponent<RectTransform>();
                RectTransform t2 = tierContTrans.GetChild(i)?.FindChildRecursive("Text On")?.GetComponent<RectTransform>();
                if (t1 == null || t2 == null) continue;
                t1.anchoredPosition = new Vector2(0, 8);
                t2.anchoredPosition = new Vector2(0, 8);
            }
            //for (int i = 0; i < 4; i++)
            //    Instantiate(tierContTrans.GetChild(i).gameObject, tierContTrans.GetChild(i).parent);
            StartCoroutine(CallbackUtil.DelayedCallback(1, delegate {
                string treePath = "GameManager/Default Game Instance(Clone)/UI Manager(Clone)/Main Canvas/RDCenterUI(Clone)/Container/TechTree/TreeContainer/TreeContent";
                Transform tree = GameObject.Find(treePath)?.transform;
                if (tree == null) return;
                for (int i = 1; i < tree.childCount; i++) {
                    Transform t = tree.GetChild(i);
                    if (t == null) continue;
                    RectTransform t1 = t.GetComponent<RectTransform>();
                    if (t1 != null) t1.sizeDelta = new Vector2(164, 76); // 82
                    RectTransform t2 = t.FindChildRecursive("ToggleOn")?.GetComponent<RectTransform>();
                    if (t2 != null) t2.sizeDelta = new Vector2(164, 76); // 82
                    RectTransform t3 = t.FindChildRecursive("Icon")?.GetComponent<RectTransform>();
                    if (t3 != null) { t3.anchoredPosition = new Vector2(15, -7); t3.sizeDelta = new Vector2(20, 20); }
                    RectTransform t4 = t.FindChildRecursive("ToggleOnIcon")?.GetComponent<RectTransform>();
                    if (t4 != null) { t4.anchoredPosition = new Vector2(65, -17); /* 27, -19 */ t4.sizeDelta = new Vector2(20, 20); }
                    RectTransform t5 = t.FindChildRecursive("Text (TMP)")?.GetComponent<RectTransform>();
                    if (t5 != null) t5.anchoredPosition = new Vector2(3, -18); // -20
                    RectTransform t6 = t.FindChildRecursive("ToggleOnText")?.GetComponent<RectTransform>();
                    if (t6 != null) t6.anchoredPosition = new Vector2(3, -18); // -20
                    RectTransform t7 = t.FindChildRecursive("CostContainer")?.GetComponent<RectTransform>();
                    if (t7 != null) { t7.sizeDelta = new Vector2(75, 16); t7.anchoredPosition = new Vector2(-11, -10); }
                    RectTransform t8 = t.FindChildRecursive("Cost")?.GetComponent<RectTransform>(); // textmesh component inside "cost"
                    if (t8 != null) { t8.sizeDelta = new Vector2(45, 16); t8.anchoredPosition = new Vector2(45, -8); }
                }
            }));
            StartCoroutine(CallbackUtil.DelayedCallback(2, delegate {
                List<TechNodeData> techNodes = new List<TechNodeData>();
                if (Game?.ScienceManager?.TechNodeDataStore?.TryGetTechNodeDataCollection(out IReadOnlyCollection<TechNodeData> tNodes) ?? false)
                    techNodes = tNodes?.ToList();
                string treePath = "GameManager/Default Game Instance(Clone)/UI Manager(Clone)/Main Canvas/RDCenterUI(Clone)/Container/TechTree/TreeContainer/TreeContent";
                Transform tree = GameObject.Find(treePath)?.transform;
                if (tree == null) return;
                int totalSci = ReUtil.GetTotalScience();
                for (int i = 1; i < tree.childCount; i++) {
                    GameObject tNodeObj = tree.GetChild(i)?.gameObject;
                    if (tNodeObj == null) continue;
                    TechNodeData tNode = techNodes.FirstOrDefault(n => n.ID == tNodeObj.name);
                    if (tNode == null) continue;
                    bool isDiscovered = tNode.RequiredSciencePoints <= 10 || totalSci > tNode.RequiredSciencePoints * 2.5;
                    if (!isDiscovered && totalSci > tNode.RequiredSciencePoints * 1.5) {
                        UnityEngine.Random.InitState(Game.SessionGuidString.GetHashCode() + tNode.RequiredSciencePoints);
                        isDiscovered = totalSci >= tNode.RequiredSciencePoints * (1.5 + UnityEngine.Random.value);
                    }
                    tNodeObj.SetActive(isDiscovered);
                }
                for (int i = 0; i < tree.GetChild(0).childCount; i++) {
                    Transform t = tree.GetChild(0).GetChild(i);
                    if (t == null) continue;
                    string[] name = t.name.Split(new string[] { "_to_" }, StringSplitOptions.None);
                    bool reqsShown = tree.gameObject.GetChild(name[0]).activeSelf && tree.gameObject.GetChild(name[1]).activeSelf;
                    t.gameObject.SetActive(reqsShown/* || !techDiscovery.Value*/);
                }
            }));
        }

        private void ChangedResCont(MessageCenterMessage message) {
            if (Game.GlobalGameState.GetGameState().GameState != GameState.VehicleAssemblyBuilder) return;
            ResourceContainerChangedMessage resMsg = (ResourceContainerChangedMessage)message;
            if (resMsg == null) return;
            lastResMsg = resMsg;
        }
        private void ReleasedUISlider(MessageCenterMessage message) {
            if (Game.GlobalGameState.GetGameState().GameState != GameState.VehicleAssemblyBuilder) return;
            if (lastResMsg == null) return;
            if (!Game.ResourceDefinitionDatabase.GetRecipesForIngredient(lastResMsg.ResourceId, out List<ResourceDefinitionID> recipeList)) return;
            if (!recipeList.Any(r => r.Value == fuelContIDVal)) return;
            fuelList.Where(r => r != lastResMsg.ResourceId).ToList().ForEach(r => lastResMsg.Container.DumpResource(r));
            lastResMsg = null;
        }

        private void ChangedVessel(MessageCenterMessage message) => UpdateGUIVessel();
        private void ChangedMousePart(MessageCenterMessage message) {
            if (!showUI || !(activeVessel?.IsKerbalEVA ?? false) || lockUI) return;
            inspectTicks = -1;
            PartUnderMouseChanged msg = (PartUnderMouseChanged)message;
            if (msg?.newPartUnderMouse == null) { UIPart = null; return; }
            PartComponent part = msg.newPartUnderMouse.SimObjectComponent;
            // if (part.PartName == "eva_kerbal") { UIPart = null; return; }
            UIPart = Position.Distance(activeVessel.transform.Position, part.transform.Position) > part.PartData.PartSizeDiameter + 1 ? null : part;
            if (UIPart != null) guiData.UpdateEVAPart();
        }

        private void CreatedVessel(MessageCenterMessage message) {
            if (ReUtil.IsGameSandbox()) return;
            VesselCreatedMessage msg = (VesselCreatedMessage)message;
            float diffScale;
            if (!Game.SessionManager.TryGetDifficultyOptionState("ScienceRewards", out diffScale)) diffScale = 1f;
            int sciGain = (int)Math.Round(Math.Ceiling(Math.Min((msg?.SerializedVessel?.parts?.Count ?? 0) * 0.015, 3)) * (ReUtil.GetSciBonus("Engineering") + 1) * diffScale);
            if (sciGain < 1) return;
            ReUtil.AddScience(sciGain);
            AddRocketScience("Engineering_Assembly", sciGain);
        }
        private void EnteredSOI(MessageCenterMessage message) {
            if (ReUtil.IsGameSandbox()) return;
            SOIEnteredMessage msg = (SOIEnteredMessage)message;
            if (msg?.bodyExited == null) return;
            float diffScale;
            if (!Game.SessionManager.TryGetDifficultyOptionState("ScienceRewards", out diffScale)) diffScale = 1f;
            int sciGain = (int)Math.Round(Math.Ceiling((msg.vessel?.VesselScienceRegionSituation.SituationScalar ?? 0) *
                (prevCelTransNames.Contains(msg.bodyExited.bodyName) && prevCelTransNames.Contains(msg.bodyEntered.bodyName) ? 0.5 : 2.0)) * (ReUtil.GetSciBonus("Control") + 1) * diffScale);
            if (sciGain < 1) return;
            prevCelTransNames = $"{msg.bodyExited.bodyName}-{msg.bodyEntered.bodyName}";
            ReUtil.AddScience(sciGain);
            AddRocketScience("Control_SOI", sciGain);
        }
        private void ScoredResearchReport(MessageCenterMessage message) {
            ResearchReportScoredMessage msg = (ResearchReportScoredMessage)message;
            CompletedResearchReport report = Game.ScienceManager.GetSubmittedResearchReports().FirstOrDefault(r => r.ResearchReportKey == msg?.ResearchReportKey);
            string key = $"{(report.ResearchReportKey.Contains("CrewObservation") ? "Psychology" : $"Science{report.ResearchReportType.ToString().Replace("Type", "")}")}_{report.ResearchReportKey.Split('_')[0]}";
            string sciType = key.Split('_')[0];
            int sciBoost = (int)Math.Round(report.FinalScienceValue * ReUtil.GetSciBonus(sciType));
            if (sciBoost > 0) ReUtil.AddScience(sciBoost);
            AddRocketScience(key, (int)Math.Round(report.FinalScienceValue * (ReUtil.GetSciBonus(sciType) + 1)));
        }
        private void CompletedMission(MessageCenterMessage message) {
            MissionCompleteMessage msg = (MissionCompleteMessage)message;

        }
        private void RecoveredVessel(MessageCenterMessage message) {
            if (ReUtil.IsGameSandbox()) return;
            VesselRecoveredMessage msg = (VesselRecoveredMessage)message;
            VesselComponent vessel = Game.UniverseModel.FindVesselComponent(msg.VesselID);
            if (vessel?.SimulationObject?.IsKerbal ?? true) return;
            Dictionary<string, double> recSci = new Dictionary<string, double> { ["Engineering_Age"] = 0 };
            foreach (PartComponent part in vessel.SimulationObject.PartOwner.Parts)
                if (part.TryGetModule(out PartComponentModule_DamageEngine moduleDmgEng) && moduleDmgEng != null) {
                    if (moduleDmgEng.DataDmg.records.Any(r => r.Key.StartsWith("Aeronautics") || r.Key.StartsWith("Propulsion")))
                        AddPartRecord(part.PartData.partName, moduleDmgEng.DataDmg.records.FirstOrDefault(r => r.Key.StartsWith("Aeronautics") || r.Key.StartsWith("Propulsion")).Value);
                    foreach (var pair in moduleDmgEng.DataDmg.records) {
                        double val = pair.Value * (ReUtil.dmgSciRates.ContainsKey(pair.Key) ? ReUtil.dmgSciRates[pair.Key] : 0.05);
                        if (recSci.ContainsKey(pair.Key))
                            recSci[pair.Key] += val;
                        else recSci[pair.Key] = val;
                        //int sci = (int)Math.Ceiling(pair.Value * (ReUtil.dmgSciRates.ContainsKey(pair.Key) ? ReUtil.dmgSciRates[pair.Key] : 0.05));
                        //AddRocketScience(pair.Key, sci);
                        //sciGain += sci;
                    }
                } else if (part.TryGetModule(out PartComponentModule_Damage moduleDmg) && moduleDmg != null) {
                    foreach (string sciType in new string[4] { "Propulsion_RCS", "Aeronautics_ControlSurface", "Electrical_Wheel", "Aeronautics_LandingGear" })
                        if (moduleDmg.DataDmg.records.TryGetValue(sciType, out double rec))
                            AddPartRecord(part.PartData.partName, rec);
                    foreach (var pair in moduleDmg.DataDmg.records) {
                        double val = pair.Value * (ReUtil.dmgSciRates.ContainsKey(pair.Key) ? ReUtil.dmgSciRates[pair.Key] : 0.05);
                        if (recSci.ContainsKey(pair.Key))
                            recSci[pair.Key] += val;
                        else recSci[pair.Key] = val;
                    }
                }
            int sciGain = 0;
            //if (recSci["Engineering_Age"] == 0)
            //    recSci.Remove("Engineering_Age");
            float diffScale;
            if (!Game.SessionManager.TryGetDifficultyOptionState("ScienceRewards", out diffScale)) diffScale = 1f;
            foreach (var pair in recSci) {
                int val = Math.Max(1, (int)Math.Round(pair.Value * (ReUtil.GetSciBonus(pair.Key.Split('_')[0]) + 1) * diffScale));
                AddRocketScience(pair.Key, val);
                sciGain += val;
            }
            if (sciGain == 0) return;
            ReUtil.AddScience(sciGain);
        }
        private void UpdatedSciencePoints(MessageCenterMessage message) =>
            StartCoroutine(CallbackUtil.DelayedCallback(1, delegate {
                // SciencePointCapacityUpdateMessage msg = (SciencePointCapacityUpdateMessage)message;
                ReAgency playerAgency = ReUtil.PlayerReAgency();
                if (playerAgency == null) return;
                int missionSci = Math.Max(0, ReUtil.GetTotalScience() - playerAgency.rocketScience.Where(s => s.Key != "Command_Missions").Select(s => s.Value).Sum()); // - Game.SessionManager.GetMyAgencyAdditionalSciencePoints()
                if (!playerAgency.rocketScience.ContainsKey("Command_Missions"))
                    playerAgency.rocketScience["Command_Missions"] = 0;
                if (playerAgency.rocketScience["Command_Missions"] != missionSci) {
                    int sciBoost = Math.Max(0, (int)Math.Round((missionSci - playerAgency.rocketScience["Command_Missions"]) * ReUtil.GetSciBonus("Command")));
                    if (sciBoost > 0) ReUtil.AddScience(sciBoost);
                    playerAgency.rocketScience["Command_Missions"] = missionSci + sciBoost;
                }
            }));

        private void AddedNewKerbal(MessageCenterMessage message) {
            KerbalAddedToRoster msg = (KerbalAddedToRoster)message;
            if (msg == null) return;
            ReUtil.PushNotify(msg.Kerbal.NameKey, "Hello", NotificationImportance.Low);
            SetupKerbalDamage(msg.Kerbal);
        }
        private void RemovedKerbal(MessageCenterMessage message) {
            KerbalRemovedFromRoster msg = (KerbalRemovedFromRoster)message;
            if (msg == null) return;
            ReUtil.PushNotify(msg.Kerbal.NameKey, "Quit", NotificationImportance.High);
            saveData.kerbals.RemoveAll(k => k.Name == msg.Kerbal.NameKey);
            saveData.kerbals.ForEach(k => AddKerbalDamage(k, "Psychology_Social_KerbonautLost", 30));
            // EmptyAgencyCheck();
        }
        private void MovedKerbal(MessageCenterMessage message) {
            KerbalLocationChanged msg = (KerbalLocationChanged)message;
            if (msg == null) return;
            KerbalDamage kerbd = saveData.kerbals.FirstOrDefault(k => k.Name == msg.Kerbal.NameKey);
            SimulationObjectModel simObj = Game.ViewController.Universe.FindSimObject(msg.Kerbal.Location.SimObjectId);
            if (simObj == null || kerbd == null) return;
            ScienceSitutation? sit = simObj.Part?.PartOwner?.SimulationObject?.Vessel?.VesselScienceRegionSituation.ResearchLocation?.ScienceSituation;
            if (!kerbd.damage.ContainsKey("Psychology_Role_WingsPending") && simObj.Part?.PartName == "eva_kerbal" && (sit == ScienceSitutation.LowOrbit || sit == ScienceSitutation.HighOrbit)) {
                AddKerbalDamage(kerbd, "Psychology_Role_WingsPending", -5, true);
                ReUtil.PushNotify(kerbd.Name, "WingsPending", NotificationImportance.Low);
            }
            // Game.SessionManager.KerbalRosterManager.GetAllKerbals().ForEach(k => Logger.LogInfo(k.Location.SimObjectId));
        }

        private void ToggleGUI() {
            GameState state = Game.GlobalGameState.GetGameState().GameState;
            if (state == GameState.Map3DView) return;
            else if (state == GameState.KerbalSpaceCenter || state == GameState.VehicleAssemblyBuilder) diagMode = false;
            UpdateGUIVessel();
            showUI = !showUI;
            // GameObject.Find("BTN-ReDiagnostic")?.GetComponent<UIValue_WriteBool_Toggle>()?.SetValue(showUI);
            if (showApp && showUI) {
                showApp = false;
                // GameObject.Find("BTN-ReKerbalLife")?.GetComponent<UIValue_WriteBool_Toggle>()?.SetValue(showApp);
            }
        }
        private void ToggleGUI(bool show) => ToggleGUI();
        private void GUIContent(int windowID) {
            GameState state = Game.GlobalGameState.GetGameState().GameState;
            bool modeBtn = false;
            GUILayout.BeginHorizontal();
            if (!minUI) modeBtn = GUILayout.Button(guiData.ModeBtn, btnStyle, GUILayout.Width(28));
            GUILayout.FlexibleSpace();
            bool minBtn = GUILayout.Button(minUI ? guiData.MaxBtn : guiData.MinBtn, btnStyle, GUILayout.Width(28));
            bool closeBtn = GUILayout.Button(guiData.CloseBtn, btnXStyle, GUILayout.Width(28));
            GUILayout.EndHorizontal();
            if (modeBtn) {
                diagMode = !diagMode;
                if (!diagMode) guiData.UpdateListMode();
                else if (activeVessel.IsKerbalEVA) guiData.UpdateEVAPart();
                else guiData.UpdateVesselPart(ReUtil.IsPALActive(UIPart.PartOwner.SimulationObject.Vessel));
            } else if (minBtn) minUI = !minUI;
            else if (closeBtn) showUI = false;
            if (!showUI || minUI || modeBtn || (activeVessel == null && state != GameState.KerbalSpaceCenter && state != GameState.VehicleAssemblyBuilder)) { 
                inspectTicks = -1; GUI.DragWindow(new Rect(0, 0, 10000, 500)); return; }
            if ((activeVessel?.IsKerbalEVA ?? false) && diagMode && UIPart == null) {
                GUILayout.Label(guiData.InspectHint);
                GUI.DragWindow(new Rect(0, 0, 10000, 500)); return;
            }
            GUILayout.BeginHorizontal(); GUILayout.BeginVertical();
            if (diagMode) {
                if (activeVessel?.IsKerbalEVA ?? false) GUIContentEVA();
                else {
                    if (ReUtil.IsPALActive(activeVessel)) // UIPart?.PartOwner?.SimulationObject?.Vessel
                        GUIContentPAL();
                    GUIContentVessel();
                }
            } else GUIContentListMode();
            GUILayout.EndVertical(); GUILayout.EndHorizontal();
            GUI.DragWindow(new Rect(0, 0, 10000, 500));
        }
        private void GUIContentEVA() {
            GUILayout.BeginHorizontal(); GUILayout.FlexibleSpace(); GUILayout.Label(guiData.PartTitle); GUILayout.FlexibleSpace(); GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal(); GUILayout.FlexibleSpace(); GUILayout.Label(guiData.Subtitle); GUILayout.FlexibleSpace(); GUILayout.EndHorizontal();
            bool isIdleEVA = !repairers.Any(r => r.Guid == activeVessel.Guid);
            bool isBeingRepaired = repairers.Count(r => r.TargetGuid == UIPart.Guid) > 0;
            bool isInspected = inspectTicks == 0;
            bool isKerbal = UIPart.PartName == "eva_kerbal";
            if (isBeingRepaired || isInspected)
                GUILayout.Label(guiData.Damage);
            if (isIdleEVA && (isInspected || isBeingRepaired))
                GUILayout.Label(isKerbal || UIPart.PartOwner.SimulationObject.Vessel.SimulationObject.Telemetry.CommNetConnectionStatus == ConnectionNodeStatus.Connected ?
                    guiData.RepairHint : guiData.CommNetReq);
            //int sel = 0;
            //if (lockUI) {
            //    GUILayout.BeginHorizontal(); GUILayout.Space(120); GUILayout.Label("Assess"); GUILayout.Label("Analyze"); GUILayout.Label("Discuss"); GUILayout.EndHorizontal();
            //    GUILayout.BeginHorizontal();
            //    GUILayout.BeginVertical(); GUILayout.Label("Veteran"); GUILayout.Label("Wings"); GUILayout.Label("Kerbonaut"); GUILayout.EndVertical();
            //    sel = GUILayout.SelectionGrid(sel, new string[] { ">¤<", ">¤<", ">¤<", ">¤<", ">¤<", ">¤<", ">¤<", ">¤<", ">¤<" }, 3, GUILayout.Width(250));

            //    GUILayout.EndHorizontal();
            //}
            if (isBeingRepaired) {
                GUILayout.BeginHorizontal(); GUILayout.FlexibleSpace(); GUILayout.Label(guiData.Repairing); GUILayout.FlexibleSpace(); GUILayout.EndHorizontal();
                foreach (string repName in guiData.Repairers)
                    GUILayout.Label(repName);
            } else if (isIdleEVA && !isInspected) {
                GUILayout.BeginHorizontal();
                GUILayout.Label($"{guiData.Inspecting}{(inspectTicks % 3 == 0 ? "." : inspectTicks % 3 == 2 ? ".." : "...")}");
                GUILayout.HorizontalSlider(inspectTicks, 7, 0, GUILayout.Width(180));
                GUILayout.EndHorizontal();
            }
        }
        private void GUIContentPAL() {
            GUILayout.BeginHorizontal();
            GUILayout.Space(10);
            GUILayout.Label(guiData.Wireframe);
            GUILayout.Space(10);
            GUILayout.BeginVertical();
            GUILayout.Space(8);
            GUILayout.Label(guiData.Impacts);
            if (ReUtil.IsPALActive(level: 3, bypassVessel: true))
                GUILayout.Label(guiData.Temperature);
            if (UIPart.PartName != "eva_kerbal") {
                if (ReUtil.IsPALActive(level: 2, bypassVessel: true))
                    GUILayout.Label(guiData.GeeForces);
                if (ReUtil.IsPALActive(level: 4, bypassVessel: true))
                    GUILayout.Label(guiData.AngularVel);
                if (ReUtil.IsPALActive(level: 6, bypassVessel: true))
                    GUILayout.Label(guiData.Instability);
                if (ReUtil.IsPALActive(level: 5, bypassVessel: true))
                    GUILayout.Label(guiData.Ullage);
                if (ReUtil.IsPALActive(level: 10, bypassVessel: true))
                    GUILayout.Label(guiData.Boiloff);
            }
            GUILayout.EndVertical();
            GUILayout.EndHorizontal();
        }
        private void GUIContentVessel() {
            bool navSerL = false;
            bool navSerR = false;
            bool navCatL = false;
            bool navCatR = false;
            bool isPart = UIPart != null && UIPart?.PartName != "eva_kerbal";
            if (isPart) GUILayout.Label(guiData.Age);
            GUILayout.Space(4);
            GUILayout.BeginHorizontal();
            GUILayout.Label(guiData.SerialTitle);
            if (isPart) navSerL = GUILayout.Button(guiData.NavLBtn, btnStyle, GUILayout.Width(28));
            GUILayout.FlexibleSpace();
            GUILayout.Label(guiData.SerialDesc);
            GUILayout.FlexibleSpace();
            if (isPart) navSerR = GUILayout.Button(guiData.NavRBtn, btnStyle, GUILayout.Width(28));
            GUILayout.EndHorizontal();
            GUILayout.Space(4);
            GUILayout.BeginHorizontal();
            GUILayout.Label(guiData.CategoryTitle);
            if (isPart) navCatL = GUILayout.Button(guiData.NavLBtn, btnStyle, GUILayout.Width(28));
            GUILayout.FlexibleSpace();
            GUILayout.Label(guiData.CategoryDesc);
            GUILayout.FlexibleSpace();
            if (isPart) navCatR = GUILayout.Button(guiData.NavRBtn, btnStyle, GUILayout.Width(28));
            GUILayout.EndHorizontal();
            if (navSerL || navSerR || navCatL || navCatR) {
                List<PartComponent> parts = UIPart.PartOwner.SimulationObject.Vessel.SimulationObject.PartOwner.Parts.ToList();
                if (navSerL || navSerR) {
                    parts = parts.Where(p => p.PartData.category == UIPart.PartData.category).ToList();
                    int i = parts.FindIndex(p => p.Guid == UIPart.Guid);
                    if (navSerL) UIPart = parts[i - 1 > -1 ? i - 1 : parts.Count - 1];
                    else UIPart = parts[i + 1 < parts.Count ? i + 1 : 0];
                } else {
                    parts = parts.GroupBy(p => p.PartData.category).Select(g => g.First()).ToList();
                    int i = parts.FindIndex(p => p.PartData.category == UIPart.PartData.category);
                    if (navCatL) UIPart = parts[i - 1 > -1 ? i - 1 : parts.Count - 1];
                    else UIPart = parts[i + 1 < parts.Count ? i + 1 : 0];
                }
                guiData.UpdateVesselPart(ReUtil.IsPALActive(UIPart.PartOwner.SimulationObject.Vessel));
            }
        }
        private void GUIContentListMode() {
            GUILayout.BeginHorizontal(); GUILayout.FlexibleSpace(); GUILayout.Label(guiData.VesselsNearby); GUILayout.FlexibleSpace(); GUILayout.EndHorizontal();
            foreach (VesselComponent vessel in guiData.VesselsList) {
                GUILayout.BeginHorizontal();
                GUILayout.Space(10);
                GUILayout.Label(vessel.DisplayName);
                GUILayout.FlexibleSpace();
                if (vessel.Guid == activeVessel.Guid && UIPart?.PartOwner?.SimulationObject?.Vessel?.Guid == activeVessel.Guid)
                    GUILayout.Label(guiData.Current);
                else if (vessel.Guid == UIPart?.PartOwner?.SimulationObject?.Vessel?.Guid)
                    GUILayout.Label(guiData.Connected);
                else if (!activeVessel.IsKerbalEVA) {
                    bool vslSwitch = GUILayout.Button(guiData.Contact);
                    if (vslSwitch) {
                        UIPart = vessel.SimulationObject?.PartOwner?.Parts?.First();
                        guiData.UpdateVesselPart(ReUtil.IsPALActive(activeVessel));
                    }
                }
                GUILayout.Space(10);
                GUILayout.EndHorizontal();
            }
            GUILayout.BeginHorizontal(); GUILayout.FlexibleSpace(); GUILayout.Label(guiData.KerbalsOnEVA); GUILayout.FlexibleSpace(); GUILayout.EndHorizontal();
            // foreach (Tuple<string, string> evaData in guiData.EVAsList) {
            foreach (VesselComponent evaVessel in guiData.EVAsList) {
                bool evaSwitch = false;
                GUILayout.BeginHorizontal();
                GUILayout.Space(10);
                GUILayout.Label(evaVessel.DisplayName);
                GUILayout.FlexibleSpace();
                GUILayout.Label(repairers.Any(r => r.Guid == evaVessel.Guid) ? guiData.Repairing : guiData.Idle);
                GUILayout.Space(10);
                if (!activeVessel.IsKerbalEVA)
                    if (evaVessel.Guid == UIPart?.PartOwner?.SimulationObject?.Vessel?.Guid)
                        GUILayout.Label(guiData.ModeBtn + " ");
                    else evaSwitch = GUILayout.Button(guiData.ModeBtn, btnStyle, GUILayout.Width(28));
                GUILayout.EndHorizontal();
                if (evaSwitch) {
                    UIPart = evaVessel.SimulationObject?.PartOwner?.Parts?.First();
                    guiData.UpdateVesselPart(ReUtil.IsPALActive(activeVessel));
                }
            }
        }
        private void UpdateGUIVessel() {
            activeVessel = Game.ViewController?.GetActiveVehicle()?.GetSimVessel();
            // lockUI = (activeVessel?.IsKerbalEVA ?? false) && repairers.Any(r => r.Guid == activeVessel.Guid);
            if (activeVessel?.IsKerbalEVA ?? true) { UIPart = null; guiData.UpdateWindowTitle(); return; }
            UIPart = activeVessel?.SimulationObject?.PartOwner?.Parts?.First();
            bool hasPAL = ReUtil.IsPALActive(activeVessel);
            guiData.UpdateWindowTitle(hasPAL);
            guiData.UpdateVesselPart(hasPAL);
        }

        private void ToggleApp() {
            KerbalDamageCheckIn();
            if (guiData.Agency == null) //  || guiData.Kerbal == null
                guiData.Agency = ReUtil.PlayerReAgency();
                // guiData.Kerbal = ReUtil.GetKerbalForAgency(guiData.Agency);
            
            if (!ReUtil.IsGameSandbox() && ReUtil.IsPlayerAgency(guiData.Agency)) {
                guiData.UpdateDiscovery();
                guiData.UpdateSciLevel();
            }
            showApp = !showApp;
            // GameObject.Find("BTN-ReKerbalLife")?.GetComponent<UIValue_WriteBool_Toggle>()?.SetValue(showApp);
            if (showUI && showApp) {
                showUI = false;
                // GameObject.Find("BTN-ReDiagnostic")?.GetComponent<UIValue_WriteBool_Toggle>()?.SetValue(showUI);
            }
        }
        private void ToggleApp(bool show) => ToggleApp();
        private void AppContent(int windowID) {
            bool modeBtn = false;
            GUILayout.BeginHorizontal();
            if (!minUI && !ReUtil.IsGameSandbox())
                modeBtn = GUILayout.Button(guiData.ModeIndex == 0 ? "<color=#0D0D0D>∞</color>" : "", guiData.ModeIndex == 0 ? btnStyle : guiData.ModeIndex == 1 ? btnKStyle : btnMStyle, GUILayout.Width(28), GUILayout.Height(28));
            else if (ReUtil.IsGameSandbox())
                GUILayout.Label(guiData.Icon);
            GUILayout.FlexibleSpace();
            bool minBtn = GUILayout.Button($"<color=#0D0D0D>{(minUI ? "□" : " - ")}</color>", btnStyle, GUILayout.Width(28));
            bool closeBtn = GUILayout.Button("<color=#0D0D0D>x</color>", btnXStyle, GUILayout.Width(28));
            GUILayout.EndHorizontal();
            if (modeBtn) guiData.ModeIndex = guiData.ModeIndex == 2 ? 0 : guiData.ModeIndex + 1;
            else if (minBtn) minUI = !minUI;
            else if (closeBtn) showApp = false;
            if (!showApp || minUI || modeBtn) { GUI.DragWindow(new Rect(0, 0, 10000, 500)); return; }
            AppContentHeader();
            AppContentAgency();
            GUI.DragWindow(new Rect(0, 0, 10000, 500));
        }
        private void AppContentHeader() {
            bool isPlayer = ReUtil.IsPlayerAgency(guiData.Agency);
            Texture2D tex = guiData.Kerbal == null ? isPlayer ? GameManager.Instance.Game.AgencyManager.FindAgencyEntryFirst().AgencyFlag.texture : 
                ReUtil.agencyFlags[guiData.Agency?.Name] : guiData.Kerbal?.Portrait.texture;
            // if (tex == null) GUILayout.Label("", GUILayout.Height(294));
            string aName = isPlayer ? (guiData.Agency?.Name ?? "") : LocalizationManager.GetTranslation($"Missions/MissionGranter/Name/{guiData.Agency.Name}");
            List<KerbalDamage> agencyKerbals = ReUtil.GetKerbalsForAgency(guiData.Agency);
            bool isChief = guiData.Kerbal?.NameKey == agencyKerbals?.FirstOrDefault()?.Name;
            KerbalDamage currentKerb = guiData.Kerbal == null ? null : agencyKerbals?.FirstOrDefault(k => k?.Name == guiData.Kerbal?.NameKey);
            // AddKerbalDamage(currentKerb, "Psychology_Social_Stalk", 0.0005);
            // GUILayout.Label(guiData.Dots, GUILayout.Height(6), GUILayout.Width(344));
            if (guiData.Kerbal == null) GUILayout.Space(28);
            GUILayout.Label(tex, GUILayout.Height(guiData.Kerbal == null ? 225 : 281)); // , GUILayout.Width(344) 
            if (guiData.Kerbal == null) GUILayout.Space(28);
            // GUILayout.Label(guiData.Dots, GUILayout.Height(6));
            GUILayout.Label(guiData.Dots, GUILayout.Height(8));
            GUILayout.BeginHorizontal();
            GUILayout.BeginVertical(); GUILayout.Space(17);
            bool navL = GUILayout.Button("", btnLStyle, GUILayout.Width(28));
            GUILayout.Space(17); GUILayout.EndVertical();
            GUILayout.FlexibleSpace();
            // if (aName.Length > 26) aName = aName.Substring(0, 26) + "...";
            GUILayout.BeginVertical(); GUILayout.FlexibleSpace();
            GUILayout.Label($"<color=#0D0D0D><size=20>{aName}</size></color>");
            GUILayout.FlexibleSpace(); GUILayout.EndVertical();
            GUILayout.FlexibleSpace();
            GUILayout.BeginVertical(); GUILayout.Space(17);
            bool navR = GUILayout.Button("", btnRStyle, GUILayout.Width(28));
            GUILayout.Space(17); GUILayout.EndVertical();
            GUILayout.EndHorizontal();
            bool modeBtn0 = false;
            bool modeBtn1 = false;
            if (!ReUtil.IsGameSandbox()) {
                List<Tuple<Texture2D, string>> agencyTypes = new List<Tuple<Texture2D, string>> { Tuple.Create(guiData.Icon, "KerbalLife/Kerbonaut"),
                Tuple.Create(AssetManager.GetAsset<Texture2D>($"KSRe/images/icon3.png"), "KerbalLife/Manufacturer"),
                Tuple.Create(AssetManager.GetAsset<Texture2D>($"KSRe/images/icon4.png"), "Menu/Escape/Science"), };
                if (!isPlayer && !ReUtil.crewAgencies.ContainsKey(guiData.Agency.Name)) agencyTypes.RemoveAt(0);
                if (!ReUtil.mfParts.ContainsKey(guiData.Agency.Name)) agencyTypes.RemoveAt(agencyTypes.Count == 2 ? 0 : 1);
                if (!isPlayer) agencyTypes.RemoveAt(agencyTypes.Count - 1);
                GUILayout.BeginHorizontal();
                foreach (var agencyType in agencyTypes) {
                    GUILayout.FlexibleSpace();
                    GUILayout.Label(agencyType.Item1);
                    GUILayout.Label($"<color=#0D0D0D><size=13>{LocalizationManager.GetTranslation(agencyType.Item2).ToUpper()}</size></color>");
                }
                GUILayout.FlexibleSpace(); GUILayout.EndHorizontal();
            }
            GUILayout.Label(guiData.Dots, GUILayout.Height(8));
            if (navL || navR) {
                List<ReAgency> navList = guiData.ModeIndex == 0 ? saveData.agencies : guiData.ModeIndex == 1 ?
                    saveData.agencies.Where(a => ReUtil.crewAgencies.ContainsKey(a.Name) || a.Name == guiData.Agency.Name).ToList() :
                    saveData.agencies.Where(a => ReUtil.mfParts.ContainsKey(a.Name) || a.Name == guiData.Agency.Name || a.Name == ReUtil.PlayerAgencyName()).ToList();
                int i = navList.FindIndex(a => a.Name == guiData.Agency.Name);
                if (navL) guiData.Agency = navList[i - 1 > -1 ? i - 1 : navList.Count - 1];
                else guiData.Agency = navList[i + 1 < navList.Count ? i + 1 : 0];
                if (guiData.AgencyIndex == 1 && !ReUtil.IsPlayerAgency(guiData.Agency) && !ReUtil.mfParts.ContainsKey(guiData.Agency.Name))
                    guiData.AgencyIndex = 0;
                if (guiData.AgencyIndex == 0 && !ReUtil.IsPlayerAgency(guiData.Agency) && !ReUtil.crewAgencies.ContainsKey(guiData.Agency.Name))
                    guiData.AgencyIndex = 1;
                guiData.Kerbal = null; // ReUtil.GetKerbalForAgency(guiData.Agency);
            }
        }
        private void AppContentScience() {
            int count = ReUtil.PlayerReAgency().rocketScience.Select(s => s.Key.Split('_')[0]).Distinct().Count();
            bool navL = false;
            bool navR = false;
            GUILayout.BeginHorizontal();
            GUILayout.Label($"<color=#0D0D0D><size=13>{LocalizationManager.GetTranslation("Missions/TriumphWindow/AcceptScienceReward").ToUpper()}:</size></color>");
            GUILayout.FlexibleSpace();
            GUILayout.Label(AssetManager.GetAsset<Texture2D>($"KSRe/images/rocket_sci.png"));
            GUILayout.Label($"<color=#0D0D0D><size=17>{ReUtil.GetTotalScience()}</size></color>");
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.Label(guiData.Discovery);
            GUILayout.HorizontalSlider(guiData.DiscoveryValue, 0f, 1f, GUILayout.Width(200));
            GUILayout.EndHorizontal();
            GUILayout.Label(guiData.Dots, GUILayout.Height(8));
            GUILayout.BeginHorizontal();
            if (count > 1) navL = GUILayout.Button("", btnLStyle, GUILayout.Width(28));
            GUILayout.FlexibleSpace();
            GUILayout.Label(guiData.SciTitle);
            GUILayout.FlexibleSpace();
            if (count > 1) navR = GUILayout.Button("", btnRStyle, GUILayout.Width(28));
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.Label(guiData.Level);
            GUILayout.Box(AssetManager.GetAsset<Texture2D>($"KSRe/images/{guiData.SciLvl}.png"), GUILayout.Width(28), GUILayout.Height(28));
            GUILayout.HorizontalSlider(guiData.SciLvlProgress, 0f, 1f, GUILayout.Width(160));
            GUILayout.EndHorizontal();
            GUILayout.BeginVertical();
            foreach (var pair in guiData.SciSubtypes) {
                GUILayout.BeginHorizontal();
                GUILayout.Label(pair.Item1);
                GUILayout.Box(AssetManager.GetAsset<Texture2D>($"KSRe/images/{Math.Truncate(pair.Item2)}.png"), GUILayout.Width(28), GUILayout.Height(28));
                GUILayout.HorizontalSlider(pair.Item2 - (float)Math.Truncate(pair.Item2), 0f, 1f, GUILayout.Width(100));
                GUILayout.EndHorizontal();
            }
            GUILayout.EndVertical();
            if (navL || navR) { // ReUtil.careerSpecTechs.Where(s => !s.Key.Contains("_")).Count();
                if (navL) guiData.SciIndex = guiData.SciIndex - 1 > -1 ? guiData.SciIndex - 1 : count - 1;
                else guiData.SciIndex = guiData.SciIndex + 1 < count ? guiData.SciIndex + 1 : 0;
                guiData.UpdateSciLevel();
            }
        }
        private void AppContentAgency() {
            bool swapBtn = false;
            bool isSandbox = ReUtil.IsGameSandbox();
            List<KerbalDamage> agencyKerbals = ReUtil.GetKerbalsForAgency(guiData.Agency);
            bool isPlayer = ReUtil.IsPlayerAgency(guiData.Agency);
            bool isChief = guiData.Kerbal?.NameKey == agencyKerbals?.FirstOrDefault()?.Name;
            KerbalDamage currentKerb = guiData.Kerbal == null ? null : agencyKerbals?.FirstOrDefault(k => k?.Name == guiData.Kerbal?.NameKey);
            string[] titles = new string[] { "KerbalLife/CrewStatus", "Career/PartGrade", "Menu/VAB/Description", "Career/Title", "" };
            GUILayout.BeginHorizontal();
            bool navL = GUILayout.Button("", btnLStyle, GUILayout.Width(28));
            GUILayout.FlexibleSpace();
            GUILayout.Label($"<color=#0D0D0D><size=19>{LocalizationManager.GetTranslation(titles[(isPlayer && guiData.AgencyIndex == 1 ? 3 : guiData.AgencyIndex)]).ToUpper()}</size></color>");
            GUILayout.FlexibleSpace();
            bool navR = GUILayout.Button("", btnRStyle, GUILayout.Width(28));
            GUILayout.EndHorizontal();
            GUILayout.Label(guiData.Dots, GUILayout.Height(8));
            if (guiData.AgencyIndex == 0) {
                if (saveData.kerbals.Count(k => k.agencyName == guiData.Agency.Name) == 0)
                    GUILayout.Label($"<color=#0D0D0D><size=14>{LocalizationManager.GetTranslation($"KerbalLife/NoKerbonautsHint", new object[] { isPlayer ? ReUtil.PlayerAgencyName() : LocalizationManager.GetTranslation($"Missions/MissionGranter/Name/{guiData.Agency.Name}") })}</size></color>");
                foreach (KerbalDamage kerbal in saveData.kerbals.Where(k => k.agencyName == guiData.Agency.Name)) {
                    // KerbalInfo kerbalInfo = null;
                    // Game.SessionManager.KerbalRosterManager.TryGetKerbalByName(kerbal.Name, out kerbalInfo);
                    bool kerbBtn = false;
                    GUILayout.BeginHorizontal();
                    if (guiData.Kerbal?.NameKey != kerbal.Name)
                        kerbBtn = GUILayout.Button("<color=#0D0D0D>>¤<</color>", btnStyle, GUILayout.Width(28), GUILayout.Height(28));
                    else GUILayout.Label(AssetManager.GetAsset<Texture2D>($"KSRe/images/icon_d{ReUtil.GetKerbalDmgInt(kerbal.damage.Values.Sum())}{(kerbal.damage.ContainsKey("Psychology_Role_Wings") ? "w" : "")}.png"), GUILayout.Width(28), GUILayout.Height(28));
                    GUILayout.Label($"<color=#0D0D0D>{kerbal.Name}</color>");
                    GUILayout.FlexibleSpace();
                    GUILayout.Label($"<color=#0D0D0D><size=14>{kerbal.status ?? ""}</size></color>");
                    GUILayout.Space(20);
                    //if (guiData.Kerbal.NameKey != kerbal.Name)
                    //    kerbBtn = GUILayout.Button("<color=#0D0D0D>>¤<</color>", btnStyle, GUILayout.Width(28));
                    //else GUILayout.Box("<color=white>>¤<</color>", GUILayout.Width(28));
                    // GUILayout.Space(8);
                    GUILayout.Label(AssetManager.GetAsset<Texture2D>($"KSRe/images/cel_{kerbal.celName ?? "Kerbin"}.png"), GUILayout.Width(28), GUILayout.Height(28)); // 
                    GUILayout.EndHorizontal();
                    if (kerbBtn) {
                        Game.SessionManager.KerbalRosterManager.TryGetKerbalByName(kerbal.Name, out guiData.Kerbal);
                        // ReUtil.PushNotify(guiData.Kerbal.NameKey, "Hello", NotificationImportance.Low);
                    }
                }
            } else if (guiData.AgencyIndex == 2) {
                string desc = isPlayer ? LocalizationManager.GetTranslation("Menu/NewCampaign/Agency Name Menu Description").Split(new string[] { "\n", "\r\n" }, StringSplitOptions.RemoveEmptyEntries)[0] : 
                    LocalizationManager.GetTranslation($"Missions/MissionGranter/Description/{guiData.Agency.Name}");
                GUILayout.Label($"<color=#0D0D0D><size=14>{desc}</size></color>"); // -------------------------------------------\n<i></i>\n-------------------------------------------
            } else if (isPlayer)
                AppContentScience();
            else if (guiData.Agency.partRecords.Count == 0)
                    GUILayout.Label($"<color=#0D0D0D><size=14>{LocalizationManager.GetTranslation("Career/PartGradeHint", new object[] { LocalizationManager.GetTranslation($"Missions/MissionGranter/Name/{guiData.Agency.Name}") })}</size></color>");
            else foreach (var pair in guiData.Agency.partRecords) {
                    float rec = (float)TryGetPartRecord(pair.Key, true);
                    GUILayout.BeginHorizontal();
                    GUILayout.Label($"<color=#0D0D0D>{LocalizationManager.GetTranslation($"Parts/Title/{pair.Key}")}</color>"); // : <b>{ReUtil.GetPartGradeStr(rec)}</b>
                    GUILayout.HorizontalSlider(rec, 0f, 1f, GUILayout.Width(150));
                    GUILayout.Box(AssetManager.GetAsset<Texture2D>($"KSRe/images/grade_{ReUtil.GetPartGradeStr(rec)}.png"), GUILayout.Width(28), GUILayout.Height(28));
                    GUILayout.EndHorizontal();
                }
            if (guiData.AgencyIndex == 0 && guiData.Kerbal != null) {
                GUILayout.Label(guiData.Dots, GUILayout.Height(8));
                GUILayout.BeginHorizontal();
                GUILayout.BeginVertical();
                GUILayout.Label($"<color=#0D0D0D><size=13>{LocalizationManager.GetTranslation($"KerbalLife/{(isChief ? "ChiefKerbonaut" : "Kerbonaut")}").ToUpper()}:</size></color>");
                GUILayout.Label(guiData.Training);
                //if (!saveData.playerConfirmed && leader != null) 
                //    guiData.newKerbName = GUILayout.TextField(guiData.newKerbName ?? "", 21, GUILayout.Width(180));
                //else
                // if (!saveData.playerConfirmed && leader != null) GUILayout.Label(guiData.Surname);
                GUILayout.EndVertical();
                GUILayout.FlexibleSpace();
                GUILayout.BeginVertical();
                GUILayout.BeginHorizontal(); GUILayout.FlexibleSpace();
                GUILayout.Label($"<color=#0D0D0D><size=18>{guiData.Kerbal?.NameKey}</size></color>");
                GUILayout.FlexibleSpace(); GUILayout.EndHorizontal();
                GUILayout.BeginHorizontal(); GUILayout.FlexibleSpace();
                GUILayout.Label($"<color=#0D0D0D>{LocalizationManager.GetTranslation($"Career/{currentKerb?.Trait}/Crew")}</color>");
                GUILayout.FlexibleSpace(); GUILayout.EndHorizontal();
                GUILayout.EndVertical();
                GUILayout.FlexibleSpace();
                if (currentKerb?.status == "KSC STANDBY") { // && (isPlayer || !isChief || isSandbox)
                    GUILayout.BeginVertical(); GUILayout.FlexibleSpace();
                    swapBtn = GUILayout.Button($"<size=13><b>{(isPlayer ? "F" : "H")}IRE</b></size>");
                    GUILayout.FlexibleSpace(); GUILayout.EndVertical();
                }
                GUILayout.EndHorizontal();
                GUILayout.Label(guiData.Dots, GUILayout.Height(8));
            }
            if (navL || navR) {
                if (navL) guiData.AgencyIndex = guiData.AgencyIndex - 1 > -1 ? guiData.AgencyIndex - 1 : 2;
                else guiData.AgencyIndex = guiData.AgencyIndex + 1 < 3 ? guiData.AgencyIndex + 1 : 0;
                if (guiData.AgencyIndex == 1 && (isSandbox || (!isPlayer && !ReUtil.mfParts.ContainsKey(guiData.Agency.Name))))
                    guiData.AgencyIndex = navL ? 0 : 2;
                if (guiData.AgencyIndex == 0 && !isPlayer && !ReUtil.crewAgencies.ContainsKey(guiData.Agency.Name))
                    guiData.AgencyIndex = navL ? 2 : 1;
                guiData.Kerbal = null;
                //if (guiData.AgencyIndex == 0)
                //    ReUtil.PushNotify(guiData.Kerbal.NameKey, "Hello", NotificationImportance.Low);
            } else if (swapBtn) {
                bool update = false;
                double socialDmg = TryGetKerbalDamage(currentKerb, "Psychology_Social");
                if (isPlayer) {
                    ReUtil.PushNotify(currentKerb.Name, "Sad", NotificationImportance.Medium);
                    double dmg = (currentKerb.damage.Where(p => p.Key.StartsWith("Psychology_Role")).Sum(p => Math.Abs(p.Value)) + TryGetKerbalDamage(currentKerb, "Psychology_Social_Fired")) * 3;
                    saveData.kerbals.Where(k => k.Name != currentKerb.Name).ToList().ForEach(k => AddKerbalDamage(k, "Psychology_Social_Fired_Other", dmg / 10));
                    AddKerbalDamage(currentKerb, "Psychology_Social_Fired_Self", dmg);
                    update = true;
                } else if (isChief) {
                    ReUtil.PushNotify(currentKerb.Name, "No", NotificationImportance.High);
                    AddKerbalDamage(currentKerb, "Psychology_Social_Harassed", socialDmg + 5);
                } else if (socialDmg > 50) {
                    ReUtil.PushNotify(currentKerb.Name, "Bully", NotificationImportance.High);
                    saveData.kerbals.Where(k => k.Name != currentKerb.Name).ToList().ForEach(k => AddKerbalDamage(k, "Psychology_Social_Harassed", 10));
                    //} else if (isChief && saveData.kerbals.FindIndex(k => k.Name == guiData.Kerbal.NameKey) > saveData.kerbals.FindIndex(k => k.Name == ReUtil.GetKerbalsForAgency(ReUtil.PlayerReAgency()).FirstOrDefault()?.Name)) {
                    //    ReUtil.PushNotify(currentKerb.Name, "No", NotificationImportance.High);
                } else if (socialDmg > 25) {
                    ReUtil.PushNotify(currentKerb.Name, "No", NotificationImportance.High);
                    AddKerbalDamage(currentKerb, "Psychology_Social_Harassed", socialDmg + 5);
                } else {
                    ReUtil.PushNotify(currentKerb.Name, "Yes", NotificationImportance.Low);
                    update = true;
                }
                if (update) {
                    ReAgency[] agencies = saveData.agencies.Where(a => a.Name != "KSC" && ReUtil.crewAgencies.ContainsKey(a.Name)).ToArray();
                    string otherAgencyName = agencies[UnityEngine.Random.Range(0, agencies.Length - 1)].Name;
                    //if (agencyKerbals.Count == 1)
                    //    saveData.kerbals.LastOrDefault(k => k.agencyName == otherAgencyName).agencyName = guiData.Agency.Name;
                    if (currentKerb != null)
                        currentKerb.agencyName = !isPlayer ? ReUtil.PlayerAgencyName() : otherAgencyName;
                    // EmptyAgencyCheck();
                    guiData.Kerbal = null; // ReUtil.GetKerbalForAgency(guiData.Agency)
                }
            }
        }

        private void KerbalDamageCheckIn() {
            List<KerbalInfo> kerbis = Game.SessionManager.KerbalRosterManager.GetAllKerbals();
            saveData.kerbals.RemoveAll(kd => kerbis.All(ki => ki.NameKey != kd.Name));
            //if (saveData.kerbals.Count < kerbis.Count)
            kerbis?.ForEach(k => SetupKerbalDamage(k));
            // EmptyAgencyCheck();
        }
        private void SetupKerbalDamage(KerbalInfo kerbi) {
            string[] vets = new string[] { "Valentina Kerman", "Jebediah Kerman", "Bill Kerman", "Bob Kerman" };
            KerbalDamage kerbd = saveData.kerbals.FirstOrDefault(k => k.Name == kerbi.NameKey);
            if (kerbd != null) {
                if (vets.Contains(kerbd.Name) && !kerbd.damage.ContainsKey("Psychology_Role_Veteran"))
                    AddKerbalDamage(kerbd, "Psychology_Role_Veteran", -10, true);
                if (TryGetKerbalDamage(kerbd, "Medicine_Atrophy") == 0)
                    AddKerbalDamage(kerbd, "Medicine_Atrophy", -10, true);
                return;
            }
            List<ReAgency> crewAgencies = saveData.agencies.Where(a => ReUtil.crewAgencies.ContainsKey(a.Name)).ToList();
            ReAgency agency = null;
            string key = ReUtil.crewAgencies.Any(p => p.Value.Contains(kerbi.NameKey)) ? ReUtil.crewAgencies.FirstOrDefault(p => p.Value.Contains(kerbi.NameKey)).Key : null;
            if (key != null)
                agency = saveData.agencies.FirstOrDefault(a => a.Name == key);
            //if (vets.Contains(kerbi.NameKey))
            //    agency = saveData.agencies.FirstOrDefault(a => a.Name == "KSC");
            //else if (kerbi.NameKey == "Tim C. Kerman")
            //    agency = saveData.agencies.FirstOrDefault(a => a.Name == "KSC");
            if (agency == null && ReUtil.GetKerbalsForAgency(ReUtil.PlayerReAgency())?.Count == 0)
                agency = ReUtil.PlayerReAgency();
            if (agency == null)
                agency = crewAgencies.Where(a => a.Name != "KSC").LastOrDefault(a => saveData.kerbals.All(k => k.agencyName != a.Name));
            if (agency == null) {
                UnityEngine.Random.InitState(kerbi.NameKey.GetHashCode());
                agency = crewAgencies.Where(a => a.Name != "KSC").ElementAt(UnityEngine.Random.Range(0, crewAgencies.Count - 1));
            }
            kerbd = new KerbalDamage(kerbi.NameKey, ReUtil.RandomTrait(), agency.Name) { status = "KSC STANDBY", celName = "Kerbin" };
            if (vets.Contains(kerbi.NameKey))
                AddKerbalDamage(kerbd, "Psychology_Role_Veteran", -10, true);
            AddKerbalDamage(kerbd, "Medicine_Atrophy", -10, true);
            saveData.kerbals.Add(kerbd);
            if (!showApp && ReUtil.IsPlayerAgency(agency) && ReUtil.GetKerbalsForAgency(agency)?.Count == 1)
                ToggleApp();
        }
        //private static void EmptyAgencyCheck() {
        //    if (saveData.kerbals.Count == 0) return;
        //    for (int i = 0; i < (saveData.agencies.Count - saveData.kerbals.Select(k => k.agencyName).Distinct().Count()); i++) {
        //        string fullAgName = saveData.agencies.LastOrDefault(a => saveData.kerbals.Count(k => k.agencyName == a.Name) > 1).Name;
        //        string emptyAgName = saveData.agencies.FirstOrDefault(a => saveData.kerbals.Count(k => k.agencyName == a.Name) == 0).Name;
        //        saveData.kerbals.LastOrDefault(k => k.agencyName == fullAgName).agencyName = emptyAgName;
        //    }
        //}
        
        private void SlowUpdateKerbalDamage(double fixedDeltaT) {
            lastSlowUpdateUT = Game.UniverseModel.UniverseTime;
            foreach (KerbalDamage kerbd in saveData.kerbals) {
                if (kerbd.damage.Keys.All(k => !k.StartsWith("Psychology_Role_Kerbonaut"))) {
                    if (kerbd.Name == saveData.kerbals.Where(k => k.agencyName == kerbd.agencyName)?.FirstOrDefault()?.Name) {
                        AddKerbalDamage(kerbd, "Psychology_Role_Kerbonaut_Chief", -10, true);
                    } else AddKerbalDamage(kerbd, "Psychology_Role_Kerbonaut_Grad", -5, true);
                }
                Game.SessionManager.KerbalRosterManager.TryGetKerbalByName(kerbd.Name, out KerbalInfo kerbi);
                if (kerbi == null) continue;
                if (kerbi.Location.SimObjectId.Guid == Game.SessionManager.KerbalRosterManager.KSCGuid.Guid) {
                    if (!kerbd.status.StartsWith("KSC"))
                        kerbd.status = "KSC STANDBY";
                    kerbd.celName = "Kerbin";
                    if (kerbd.damage.ContainsKey("Psychology_Role_WingsPending")) {
                        kerbd.damage.Remove("Psychology_Role_WingsPending");
                        AddKerbalDamage(kerbd, "Psychology_Role_Wings", -10, true);
                        ReUtil.PushNotify(kerbd.Name, "Wings", NotificationImportance.Low, false);
                    }
                    continue;
                }
                SimulationObjectModel simObj = Game.ViewController.Universe.FindSimObject(kerbi.Location.SimObjectId);
                kerbd.celName = simObj?.Part?.PartCelestialBody?.Name;
                if (repairers.Any(r => r.Name == kerbd.Name))
                    kerbd.status = "EVA REPAIR";
                else {
                    string partName = simObj?.Part?.PartName;
                    if (partName == null || ReUtil.partKerbStats.All(s => !s.Value.Contains(partName ?? "-")))
                        kerbd.status = "UNKNOWN";
                    else kerbd.status = ReUtil.partKerbStats.FirstOrDefault(s => s.Value.Contains(partName)).Key;
                }
                //double geeForce = simObj?.Part?.PartOwner?.SimulationObject?.Vessel?.geeForce ?? 0;
                //if (kerbd.status == "EXERCISE" && TryGetKerbalDamage(kerbd, "Medicine_Atrophy") < (1 - Mathf.Clamp01((float)geeForce)) * 25)
                //    AddKerbalDamage(kerbd, "Medicine_Atrophy", (fixedDeltaT / 21600) * (0.25 - geeForce));
            }
        }
        
        private void InitOrUpdateSave() {
            Version.TryParse(saveData.modVersion ?? VERSION, out Version version);
            if (saveData.modVersion != null && version?.Major == 24 && version?.Minor >= 2) {
                ReAgency player = ReUtil.PlayerReAgency();
                Dictionary<string, string> fixSciType = new Dictionary<string, string>() { ["Engineering_Wheel"] = "Electrical Wheel", ["Flight_SOI"] = "Control_SOI",
                    ["Command_CrewObservation"] = "Psychology_CrewObservation" };
                foreach (var pair in fixSciType.Where(p => player?.rocketScience?.ContainsKey(p.Key) ?? false)) {
                    if (player.rocketScience.ContainsKey(pair.Value))
                        player.rocketScience[pair.Value] += player.rocketScience[pair.Key];
                    else player.rocketScience[pair.Value] = player.rocketScience[pair.Key];
                    player.rocketScience.Remove(pair.Key);
                }
                saveData.modVersion = VERSION;
                return;
            }
            saveData.modVersion = VERSION;
            saveData.lastDailyUpdateUT = Math.Round(Game.UniverseModel.UniverseTime);
            ReAgency playerAgency = new ReAgency(Game.AgencyManager.FindAgencyEntryFirst().AgencyName);
            List<ReAgency> agencies = (ReUtil.IsGameSandbox() ? ReUtil.crewAgencies.Keys : ReUtil.crewAgencies.Keys.Take(3)).Select(a => new ReAgency(a)).ToList();
            if (!ReUtil.IsGameSandbox()) {
                agencies.Add(new ReAgency("ReactionSystems"));
                agencies.Add(new ReAgency("Lightyear"));
            }
            if (saveData.agencies == null) {
                if (!ReUtil.IsGameSandbox()) {
                    playerAgency.rocketScience = new Dictionary<string, int>() { ["Engineering_Assembly"] = 0 };
                    ReUtil.PushNotify($"Missions/MissionGranter/Name/ReactionSystems", "NewAgency", NotificationImportance.Low, false);
                    ReUtil.PushNotify($"Missions/MissionGranter/Name/Lightyear", "NewAgency", NotificationImportance.Low, false);
                }
                saveData.agencies = new List<ReAgency>() { playerAgency };
            } else {
                ReAgency oldPlayerAgency = saveData.agencies.FirstOrDefault(a => a.rocketScience.Count != 0);
                playerAgency.rocketScience = oldPlayerAgency.rocketScience;
                saveData.agencies.Remove(oldPlayerAgency);
                saveData.agencies.RemoveAll(a => a.partRecords.Count == 0);
                saveData.agencies.Add(playerAgency);
                agencies.RemoveAll(a => saveData.agencies.Any(sa => sa.Name == a.Name));
            }
            saveData.agencies.AddRange(agencies);
            if (saveData.kerbals == null)
                saveData.kerbals = new List<KerbalDamage>();
            if (saveData.pals == null) saveData.pals = new Dictionary<string, double>();
        }

        internal static void AddKerbalDamage(string name, string type, double amount) {
            KerbalDamage kerb = saveData.kerbals.FirstOrDefault(k => k.Name == name);
            if (kerb == null) return;
            AddKerbalDamage(kerb, type, amount);
        }
        internal static void AddKerbalDamage(KerbalDamage kerb, string type, double amount, bool set = false) {
            if (kerb == null) return;
            UnityEngine.Random.InitState((kerb.Name + kerb.Trait + type).GetHashCode());
            amount *= UnityEngine.Random.value * 2;
            if (kerb.damage.ContainsKey(type) && !set)
                kerb.damage[type] += amount;
            else kerb.damage[type] = amount;
            if (kerb.damage.Values.Sum() > 100) {
                Game.SessionManager.KerbalRosterManager.TryGetKerbalByName(kerb.Name, out KerbalInfo kerbal);
                if (kerbal == null) return;
                Game.SessionManager.KerbalRosterManager.DestroyKerbal(kerbal.Id);
                return;
            }
            if (set || amount > 0 || !new string[] { "Medicine_Impacts", "Medicine_Atrophy", "Psychology_Therapy" }.Contains(type)) return;
            KerbalLifeRewards(type, kerb.damage[type] - amount, kerb.damage[type]);
        }
        internal static void KerbalLifeRewards(string type, double prevDmg = 0, double newDmg = 0, bool force = false) {
            bool check = false;
            if (!force)
                for (int i = -10; i < 10; i++)
                    if (prevDmg > i * 10 && newDmg < i * 10) {
                        check = true; break;
                    }
            if (!check && !force) return;
            float diffScale;
            if (!Game.SessionManager.TryGetDifficultyOptionState("ScienceRewards", out diffScale)) diffScale = 1f;
            int sciGain = Math.Max(2, (int)Math.Round((ReUtil.GetSciBonus(type) + 1) * diffScale * (force ? 2 : 1)));
            ReUtil.AddScience(sciGain);
            AddRocketScience(type, sciGain);
        }
        internal static double TryGetKerbalDamage(KerbalDamage kerb, string type) {
            if (kerb.damage.All(p => !p.Key.StartsWith(type))) return 0;
            return kerb.damage.Where(p => p.Key.StartsWith(type)).Sum(p => p.Value);
        }
        internal static void AddPartRecord(string partName, double amount) {
            if (ReUtil.IsGameSandbox()) return;
            string mfKey = ReUtil.GetPartMfrKey(partName);
            if (mfKey == null || mfKey == "") return;
            ReAgency mfAgency = saveData.agencies?.FirstOrDefault(a => a.Name == mfKey);
            if (mfAgency == null) {
                mfAgency = new ReAgency(mfKey);
                saveData.agencies.Add(mfAgency);
                ReUtil.PushNotify($"Missions/MissionGranter/Name/{mfKey}", "NewAgency", NotificationImportance.Low, false);
            }
            if (mfAgency.partRecords == null)
                mfAgency.partRecords = new Dictionary<string, double>();
            if (!mfAgency.partRecords.ContainsKey(partName)) {
                mfAgency.partRecords[partName] = amount;
                ReUtil.PushNotify($"Missions/MissionGranter/Name/{mfKey}", "NewPartGrade", NotificationImportance.Low, false, LocalizationManager.GetTranslation($"Parts/Title/{partName}"));
            } else mfAgency.partRecords[partName] += amount;
        }
        internal static void AddRocketScience(string sciType, int amount) {
            if (ReUtil.IsGameSandbox()) return;
            ReAgency playerAgency = ReUtil.PlayerReAgency();
            if (playerAgency == null) return;
            if (playerAgency.rocketScience.ContainsKey(sciType))
                playerAgency.rocketScience[sciType] += amount;
            else playerAgency.rocketScience[sciType] = amount;
        }
        internal static double TryGetPartRecord(string partName, bool asPct = false) {
            double record = 0;
            if (saveData.agencies?.Any(a => a.partRecords.ContainsKey(partName)) ?? false)
                record = saveData.agencies.FirstOrDefault(a => a.partRecords.ContainsKey(partName)).partRecords[partName];
            if (asPct && record > 0) record = Math.Min(Math.Sqrt(record / 10) / 10, 1);
            return record;
        }
        
        public class GUIData {

            public int SciIndex, AgencyIndex, ModeIndex;
            public KerbalInfo Kerbal;
            public ReAgency Agency;
            public string WindowTitle { get; private set; }
            public string AppTitle { get; private set; }
            public string ModeBtn { get; private set; }
            public string MinBtn { get; private set; }
            public string MaxBtn { get; private set; }
            public string CloseBtn { get; private set; }
            public string NavLBtn { get; private set; }
            public string NavRBtn { get; private set; }
            public string OkBtn { get; private set; }
            public Texture2D Icon { get; private set; }
            public Texture2D Dots { get; private set; }
            public string Name { get; private set; }
            public string Surname { get; private set; }
            public string Training { get; private set; }
            public string Discovery { get; private set; }
            public string InspectHint { get; private set; }
            public string PartTitle { get; private set; }
            public string Subtitle { get; private set; }
            public string Damage { get; private set; }
            public string RepairHint { get; private set; }
            public string CommNetReq { get; private set; }
            public string RepairStatus { get; private set; }
            public string RepairTitle { get; private set; }
            public List<string> Repairers { get; private set; }
            public string Inspecting { get; private set; }
            public Texture2D Wireframe { get; private set; }
            public string Impacts { get; private set; }
            public string Temperature { get; private set; }
            public string GeeForces { get; private set; }
            public string AngularVel { get; private set; }
            public string Instability { get; private set; }
            public string Ullage { get; private set; }
            public string Boiloff { get; private set; }
            public string Age { get; private set; }
            public string SerialTitle { get; private set; }
            public string SerialDesc { get; private set; }
            public string CategoryTitle { get; private set; }
            public string CategoryDesc { get; private set; }
            public string VesselsNearby { get; private set; }
            public List<VesselComponent> VesselsList { get; private set; }
            public List<VesselComponent> EVAsList { get; private set; }

            public string Current { get; private set; }
            public string Connected { get; private set; }
            public string Contact { get; private set; }
            public string KerbalsOnEVA { get; private set; }
            // public List<Tuple<string, string>> EVAsList { get; private set; }
            public string Repairing { get; private set; }
            public string Idle { get; private set; }
            public float DiscoveryValue { get; private set; }
            public string Level { get; private set; }
            public string SciTitle { get; private set; }
            public int SciLvl { get; private set; }
            public float SciLvlProgress { get; private set; }
            public List<Tuple<string, float>> SciSubtypes { get; private set; }

            public GUIData() {
                Repairers = new List<string>();
                VesselsList = new List<VesselComponent>();
                EVAsList = new List<VesselComponent>();
                // EVAsList = new List<Tuple<string, string>>();
                UpdateWindowTitle();
                AppTitle = $"<color=#0D0D0D><size=13> {LocalizationManager.GetTranslation("KerbalLife/Title").ToUpper()} --------------------/      </size></color>";
                ModeBtn = "<color=#D6E0FF>>¤<</color>";
                MinBtn = "<color=#D6E0FF>-</color>";
                MaxBtn = "<color=#D6E0FF>□</color>";
                CloseBtn = "<color=#D6E0FF>x</color>";
                NavLBtn = "<color=#D6E0FF><</color>";
                NavRBtn = "<color=#D6E0FF>></color>";
                OkBtn = LocalizationManager.GetTranslation("Application/OK");
                Icon = AssetManager.GetAsset<Texture2D>($"KSRe/images/icon.png");
                Dots = AssetManager.GetAsset<Texture2D>($"KSRe/images/dots.png");
                Name = $"<color=#0D0D0D>{LocalizationManager.GetTranslation("Menu/SaveLoad/Name")}:</color> ";
                Surname = $"<color=#0D0D0D>{LocalizationManager.GetTranslation("Career/Surname")}</color> ";
                Training = $"<color=#0D0D0D><size=13>{LocalizationManager.GetTranslation("Career/Training").ToUpper()}:</size></color> ";
                Discovery = $"<color=#0D0D0D><size=13>{LocalizationManager.GetTranslation("Career/Discovery").ToUpper()}:</size></color> ";
                InspectHint = $"<color=yellow>{LocalizationManager.GetTranslation("Diagnostic/InspectHint")}</color>";
                RepairStatus = $"<color=#D6E0FF>- {LocalizationManager.GetTranslation("PartModules/Damage/Repairing")} -</color>";
                RepairHint = $"<color=yellow>{LocalizationManager.GetTranslation("Diagnostic/RepairHint", new object[1] { repairKeyCode.Value.Description() })}</color>";
                CommNetReq = $"<color=#D45455>{LocalizationManager.GetTranslation("Diagnostic/CommNetRequired")}</color>";
                Inspecting = LocalizationManager.GetTranslation("PartModules/Damage/Inspecting");
                SerialTitle = $"{LocalizationManager.GetTranslation("PartModules/Damage/Serial", new object[1] { "" })}  ";
                CategoryTitle = $"{LocalizationManager.GetTranslation("VAB/PartsPicker/type")}:      ";
                VesselsNearby = $"<color=#D6E0FF>- {LocalizationManager.GetTranslation("Diagnostic/VesselsNearby")} -</color>";
                Current = LocalizationManager.GetTranslation("Diagnostic/Current");
                Connected = LocalizationManager.GetTranslation("Diagnostic/Connected");
                Contact = $"<color=#D6E0FF>{LocalizationManager.GetTranslation("Diagnostic/Contact")}</color>";
                KerbalsOnEVA = $"<color=#D6E0FF>- {LocalizationManager.GetTranslation("Diagnostic/KerbalsOnEVA")} -</color>";
                Repairing = LocalizationManager.GetTranslation("PartModules/Damage/Repairing");
                Idle = LocalizationManager.GetTranslation("Diagnostic/Idle");
            }

            public void Reset() {
                Agency = null;
                Kerbal = null;
                ModeIndex = 0;
                AgencyIndex = 0;
            }
            
            public void UpdateWindowTitle(bool hasPAL = false) => WindowTitle = $"<color=#D6E0FF><size=13> {LocalizationManager.GetTranslation(hasPAL ? "Diagnostic/PAL5000" : "Diagnostic/Title").ToUpper()} --------------------/      </size></color>";

            public void UpdateEVAPart() {
                bool isKerbal = UIPart.PartName == "eva_kerbal";
                PartTitle = $"<b>{(isKerbal ? Game.SessionManager.KerbalRosterManager.GetAllKerbalsInSimObject(UIPart.SimulationObject.GlobalId).First().NameKey : LocalizationManager.GetTranslation($"Parts/Title/{UIPart.PartName}"))}</b>";
                Subtitle = $"<color=#5B5FDB>#</color> <color=#C6CEDC><size=13>{LocalizationManager.GetTranslation($"Parts/Subtitle/{UIPart.PartName}").ToUpper()}</size></color>";
                Inspecting = LocalizationManager.GetTranslation(isKerbal ? "KerbalLife/CheckIn" : "PartModules/Damage/Inspecting");
                RepairHint = $"<color=yellow>{LocalizationManager.GetTranslation(isKerbal ? "KerbalLife/ChatHint" : "Diagnostic/RepairHint", new object[1] { repairKeyCode.Value.Description() })}</color>";
                Repairing = LocalizationManager.GetTranslation(isKerbal ? "KerbalLife/Chatting" : "PartModules/Damage/Repairing");
            }
            public void UpdateEVADamage() => 
                Damage = $"{LocalizationManager.GetTranslation("PartModules/Damage/Name")}: {(UIPart.PartName == "eva_kerbal" ? "?" : ReUtil.GetDamageStr(UIPartDmg))}"; // <color=#b4d455>Happy :)</color>
            public void UpdateEVARepairers() => Repairers = repairers.Where(r => r.TargetGuid == UIPart.Guid).Select(r => r.Name).ToList();

            public void UpdateForPAL() {
                bool isKerbal = UIPart.PartName == "eva_kerbal";
                Wireframe = AssetManager.GetAsset<Texture2D>($"KSRe/images/wf_{(isKerbal ? "eva" : UIPart.PartData.category + "")}.png");
                Impacts = $"{LocalizationManager.GetTranslation("Diagnostic/Impacts")}: " +
                    (UIPartImpacts.Item1 != UIPartImpacts.Item2 ? $"{ReUtil.GetColorForRange(UIPart.CrashTolerance * 0.667, UIPart.CrashTolerance, UIPartImpacts.Item1)}{UIPartImpacts.Item1:N1}</color>-" : "") +
                    $"{ReUtil.GetColorForRange(UIPart.CrashTolerance * 0.667, UIPart.CrashTolerance, UIPartImpacts.Item2)}{UIPartImpacts.Item2:N1}</color> {LocalizationManager.GetTranslation("Unit/Symbol/MetersPerSecond")}";
                Temperature = $"{LocalizationManager.GetTranslation("Diagnostic/Temperature")}: {ReUtil.GetColorForRange(UIPart.MaxTemp * 0.6, UIPart.MaxTemp * 0.8, UIPart.Temperature)}{UIPart.Temperature:N0}{LocalizationManager.GetTranslation("Unit/Symbol/Kelvin")}</color>";
                GeeForces = $"{LocalizationManager.GetTranslation("Diagnostic/GeeForces")}: {ReUtil.GetColorForRange(UIPart.CrashTolerance, UIPart.CrashTolerance * 1.25, UIPart.PartOwner.SimulationObject.Vessel.geeForce)}{UIPart.PartOwner.SimulationObject.Vessel.geeForce:N2}</color>";
                AngularVel = $"{LocalizationManager.GetTranslation("Diagnostic/Rotation")}: {UIPart.PartOwner.SimulationObject.Vessel.AngularVelocity.relativeAngularVelocity.magnitude:N4}";
                Instability = $"{LocalizationManager.GetTranslation("Diagnostic/Instability")}: {ReUtil.GetColorForRange(0, 1, UIEngInstability)}{UIEngInstability:P0}</color>";
                Ullage = $"{LocalizationManager.GetTranslation("Diagnostic/Ullage")}: {ReUtil.GetUllageStr(UIPart.PartOwner.SimulationObject.Vessel.geeForce)}";
                bool isBoiling = "0040-Methalox|0050-Methane|0060-Monopropellant|0065-Nose Cone".Contains(UIPart.PartData.family) && UIPart.PartResourceContainer.GetResourceStoredMass(fuelList.Last()) > 0;
                Boiloff = $"{LocalizationManager.GetTranslation("Diagnostic/Boiloff")}: {ReUtil.GetColorForRange(50, 650, isBoiling ? UIPart.Temperature : 0)}{(isBoiling ? Math.Max(0, UIPart.ThermalData.Temperature - 50) / 300 : 0):N1}% / {LocalizationManager.GetTranslation("Units/Symbol/Days")}</color>";
            }
            public void UpdateForVessel(bool hasPAL) {
                Age = $"{LocalizationManager.GetTranslation("Diagnostic/Age")}: {ReUtil.GetColorForRange(0, 118000000, UIPart.PartOwner.SimulationObject.Vessel.TimeSinceLaunch) + Units.FormatTimeString(UIPart.PartOwner.SimulationObject.Vessel.TimeSinceLaunch)}</color>";
                if (hasPAL) UpdateForPAL();
            }
            public void UpdateVesselPart(bool hasPAL) {
                bool isKerbal = UIPart.PartName == "eva_kerbal";
                SerialTitle = $"{LocalizationManager.GetTranslation("PartModules/Damage/Serial", new object[1] { "" })}  "; // isKerbal ? LocalizationManager.GetTranslation("VAB/SaveAndLoad/Name") : 
                SerialDesc = UIPart.Guid.Substring(24); // isKerbal ? UIPart.PartOwner.SimulationObject.Vessel.DisplayName : 
                CategoryDesc = LocalizationManager.GetTranslation(isKerbal ? "Diagnostic/EVASuit" : $"PartsManager/{UIPart.PartData.category}");
                UIPartImpacts = Tuple.Create(0f, 0f);
                UIEngInstability = 0.0;
                UpdateForVessel(hasPAL);
            }

            public void UpdateListMode() {
                VesselsList = Game.ViewController.VesselsInRange.Where(v => !v.IsKerbalEVA).ToList();
                EVAsList = Game.ViewController.VesselsInRange.Where(v => v.IsKerbalEVA).ToList();
                //EVAsList = Game.ViewController.VesselsInRange.Where(v => v.IsKerbalEVA).Select(v => Tuple.Create(v.DisplayName, 
                //    repairers.Any(r => r.Guid == v.Guid) ? Repairing : Idle)).ToList();
            }

            public void UpdateDiscovery() {
                List<TechNodeData> techNodes = new List<TechNodeData>();
                if (Game.ScienceManager?.TechNodeDataStore?.TryGetTechNodeDataCollection(out IReadOnlyCollection<TechNodeData> tNodes) ?? false)
                    techNodes = tNodes?.ToList();
                if (techNodes.Count == 0) { DiscoveryValue = 0f; return; }
                List<int> costs = techNodes.Select(t => t.RequiredSciencePoints).Distinct().ToList();
                for (int i = 0; i < costs.Count; i++) {
                    UnityEngine.Random.InitState(Game.SessionGuidString.GetHashCode() + costs[i]);
                    costs[i] = (int)Math.Round(costs[i] * (1.5 + UnityEngine.Random.value));
                }
                int sci = ReUtil.GetTotalScience();
                int prev = costs.TakeWhile(c => c < sci).LastOrDefault();
                int next = Math.Max(techNodes.Select(t => t.RequiredSciencePoints * 2).Distinct().SkipWhile(c => c <= sci).FirstOrDefault(), 15);
                DiscoveryValue = Mathf.Clamp01((float)(sci - prev) / (next - prev));
            }
            public void UpdateSciLevel() {
                ReAgency player = ReUtil.PlayerReAgency();
                string sciName = ReUtil.PlayerReAgency().rocketScience.Select(s => s.Key.Split('_')[0]).Distinct().ElementAt(SciIndex);
                SciTitle = $"<color=#0D0D0D><size=19>{LocalizationManager.GetTranslation($"Career/{sciName}/Title").ToUpper()}</size></color>";
                int sci = player.rocketScience.Where(s => s.Key.StartsWith(sciName)).Select(s => s.Value).Sum();
                SciLvl = Mathf.Clamp(ReUtil.sciLvls.Keys.TakeWhile(l => l <= sci).Count() - 1, 0, ReUtil.sciLvls.Count - 3);
                int prev = ReUtil.sciLvls.Keys.ElementAt(SciLvl);
                int next = SciLvl == ReUtil.sciLvls.Count - 3 ? 0 : ReUtil.sciLvls.Keys.ElementAt(SciLvl + 1); //ReUtil.sciLvlBonuses.Keys.Skip(SciLvl + 1).FirstOrDefault()
                SciLvlProgress = Mathf.Clamp01((float)(sci - prev) / (next - prev));
                if (ReUtil.PlayerTrait() == sciName) SciLvl += 2;
                // Level = $"<color=#0D0D0D>{LocalizationManager.GetTranslation("Career/Level")}: {SciLvl} (+{ReUtil.sciLvls.ElementAt(SciLvl).Value:P0})</color>";
                Level = $"<color=#0D0D0D>[ +{ReUtil.sciLvls.ElementAt(SciLvl).Value:P0} ]  <size=14>{LocalizationManager.GetTranslation("Career/Level").ToUpper()}:</size></color>";
                //List<int> subLvls = ReUtil.sciLvlBonuses.Keys.Take(ReUtil.sciLvlBonuses.Count - 2).ToList();
                //List<int> halfLvls = subLvls.Skip(1).Select(i => i / 2).ToList();
                //subLvls.AddRange(halfLvls);
                //subLvls = subLvls.Distinct().ToList();
                //subLvls.Sort();
                SciSubtypes = new List<Tuple<string, float>>();
                foreach (var pair in player.rocketScience.Where(s => s.Key.StartsWith(sciName))) {
                    int subLvl = Mathf.Clamp(ReUtil.sciLvls.Keys.TakeWhile(l => l <= pair.Value).Count() - 1, 0, ReUtil.sciLvls.Keys.Count - 3);
                    int prevSub = ReUtil.sciLvls.Keys.ElementAt(subLvl);
                    int nextSub = subLvl == ReUtil.sciLvls.Keys.Count - 3 ? 0 : ReUtil.sciLvls.Keys.ElementAt(subLvl + 1);
                    SciSubtypes.Add(Tuple.Create($"<color=#0D0D0D><size=13>:: {LocalizationManager.GetTranslation(ReUtil.GetSciLocKey(pair.Key))}</size></color>", // {subLvl}
                        subLvl + Mathf.Clamp01((float)(pair.Value - prevSub) / (nextSub - prevSub))));
                }
            }
        
        }

        public class ReSaveData {
            public string modVersion;
            public double lastDailyUpdateUT;
            public List<ReAgency> agencies;
            public List<KerbalDamage> kerbals;
            public Dictionary<string, double> pals;
        }

        public class ReAgencyData {
            public string Name { get; private set; }
            public Dictionary<string, int> rocketScience;
            public Dictionary<string, double> partRecords;

            public ReAgencyData(string name) {
                Name = name;
                rocketScience = new Dictionary<string, int>();
                partRecords = new Dictionary<string, double>();
            }

        }
        
        public class KerbalDamageData {
            public string Name { get; private set; }
            public string Trait { get; private set; }
            public string agencyName;
            public Dictionary<string, double> damage;
            // public Dictionary<string, double> records;

            public KerbalDamageData(string name, string trait, string agency) {
                Name = name;
                Trait = trait;
                agencyName = agency;
                damage = new Dictionary<string, double>();
                // records = new Dictionary<string, double>();
            }

        }
    }

}

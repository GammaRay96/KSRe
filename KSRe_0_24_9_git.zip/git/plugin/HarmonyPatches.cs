﻿using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using I2.Loc;
using KSP;
using KSP.Api.CoreTypes;
using KSP.Game;
using KSP.Game.Science;
using KSP.Iteration.UI.Binding;
using KSP.Messages;
using KSP.Modules;
using KSP.Networking.MP.GameClient;
using KSP.OAB;
using KSP.Rendering.Planets;
using KSP.Sim.Definitions;
using KSP.Sim.DeltaV;
using KSP.Sim.impl;
using KSP.Sim.ResourceSystem;
using KSP.UI;
using KSP.UI.Binding.Widget;
using KSP.UI.Flight;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace KSRe {

    [HarmonyPatch]
    public class ReHarmony {

        [HarmonyPatch(typeof(Curtain), "Awake")]
        [HarmonyPrefix]
        public static void FixLoadingScreen(Curtain __instance) => 
            typeof(Curtain).GetField("_appStartLoadingScreenSprite1", BindingFlags.Instance | BindingFlags.NonPublic)?.SetValue(__instance, null);

        [HarmonyPatch(typeof(PopulationComponent), nameof(PopulationComponent.OnStart))]
        [HarmonyPrefix]
        public static void AddKerbalSpawnDelay(PopulationComponent __instance) =>
            typeof(PopulationComponent).GetField("_refillDelay", BindingFlags.Instance | BindingFlags.NonPublic)?.SetValue(__instance, 0.8);

        [HarmonyPatch(typeof(PopulationComponent), "UpdateCurrentKerbalCount")]
        [HarmonyPostfix]
        public static void FixKerbalSpawnCap(PopulationComponent __instance) {
            typeof(PopulationComponent).GetField("_refillKerbalLimit", BindingFlags.Instance | BindingFlags.NonPublic)?.SetValue(__instance, ReUtil.IsGameSandbox() ? 10 : GameManager.Instance.Game.UniverseModel.UniverseTime < 10 ? 6 : 0);
            typeof(PopulationComponent).GetField("_refillKerbalEmptySubIdOnly", BindingFlags.Instance | BindingFlags.NonPublic)?.SetValue(__instance, ReUtil.IsGameSandbox());
        }

        [HarmonyPatch(typeof(PartInfoOverlay), "PopulateCoreInfoFromPart")]
        [HarmonyPostfix]
        public static void FixPartStats(IObjectAssemblyAvailablePart IOBAPart, ref List<KeyValuePair<string, string>> __result) {
            __result[0] = new KeyValuePair<string, string>(__result[0].Key, $"{IOBAPart.Mass:F3} {Units.SymbolTonne}");
            if (IOBAPart.CrewCapacity > 0) {
                __result.Add(new KeyValuePair<string, string>(OABLocalization.GetTranslation("VAB/Tooltip/Crew Capacity"), IOBAPart.CrewCapacity + ""));
                if (ReUtil.partKerbStats.Any(p => p.Value.Contains(IOBAPart.Name)))
                    __result.Add(new KeyValuePair<string, string>(OABLocalization.GetTranslation("KerbalLife/Title"), ReUtil.partKerbStats.FirstOrDefault(p => p.Value.Contains(IOBAPart.Name)).Key));
            }
        }

        [HarmonyPatch(typeof(PartInfoOverlay), "PopulateResourceInfoFromPart")]
        [HarmonyPostfix]
        public static void FixFuelContainerTotal(List<KeyValuePair<string, string>> dict, IObjectAssemblyResource[] resourceArray) {
            if (!resourceArray.Any(r => r.Name == "FuelContainer")) return;
            dict[dict.Count - 1] = new KeyValuePair<string, string>(dict.Last().Key, $"~{resourceArray.First(r => r.Name == "FuelContainer").Capacity} {Units.SymbolTonne}");
        }
        
        [HarmonyPatch(typeof(PartInfoOverlay), "PopulateEngineThrustAndISP")]
        [HarmonyPostfix]
        public static void ReEngineStats(List<KeyValuePair<string, string>> dictToPopulate, IObjectAssemblyAvailablePart IOABPart) {
            if (!(IOABPart is OABPartData) || IOABPart.Category != PartCategories.Engine) return;
            if (!IOABPart.PartData.serializedPartModules.Any(m => m.BehaviourType == typeof(Module_Engine))) return;
            Data_Engine engine = (Data_Engine)IOABPart.PartData.serializedPartModules.First(m => m.BehaviourType == typeof(Module_Engine)).ModuleData.First(d =>
                d.DataObject.DataType == typeof(Data_Engine)).DataObject;
            Data_Engine.EngineMode mode = engine.engineModes.First();
            dictToPopulate.RemoveAt(dictToPopulate.Count - 4);
            dictToPopulate[dictToPopulate.Count - 3] = new KeyValuePair<string, string>(
                OABLocalization.GetTranslation($"VAB/Tooltip/Thrust ({(mode.engineType != EngineType.Turbine ? "Vacuum" : "Atmo")})"),
                dictToPopulate[dictToPopulate.Count - 3].Value);
            string ispStr = $"{dictToPopulate[dictToPopulate.Count - 1].Value}";
            if (mode.engineType != EngineType.Turbine) ispStr = $"{ispStr} - {dictToPopulate[dictToPopulate.Count - 2].Value}";
            dictToPopulate[dictToPopulate.Count - 2] = new KeyValuePair<string, string>(
                $"{OABLocalization.GetTranslation($"VAB/Tooltip/ISP{(mode.engineType == EngineType.Turbine ? " (Atmo)" : "")}")}" +
                (mode.engineType != EngineType.Turbine ? $" (0 - 1 < {mode.atmosphereCurve.Curve?.keys?.Last().time:N0} {OABLocalization.GetTranslation("Unit/Symbol/Atmosphere")})" : ""), ispStr);
            dictToPopulate.RemoveAt(dictToPopulate.Count - 1);
            dictToPopulate.Insert(dictToPopulate.Count - 1, new KeyValuePair<string, string>(OABLocalization.GetTranslation("VAB/StagingStack/TWR"),
                $"{mode.maxThrust / ((mode.engineType != EngineType.SolidBooster ? IOABPart.Mass : IOABPart.TotalMass) * GameManager.Instance.Game.UniverseModel.HomeWorld.gravityASL * 10):N2}"));
            if (mode.engineType != EngineType.SolidBooster) {
                string throttleStr = Math.Abs(mode.maxThrust - mode.minThrust) > 0.1 ? $"{mode.minThrust / mode.maxThrust * 100:N0}-{1:P0}" : "-";
                dictToPopulate.Add(new KeyValuePair<string, string>(OABLocalization.GetTranslation("PartModules/Engine/EngineThrottle"), throttleStr));
            }
            string fuelStr = "";
            if (mode.propellant.mixtureName == "Methalox")
                fuelStr = $"{OABLocalization.GetTranslation("Resource/Abbreviation/Ox")} : {OABLocalization.GetTranslation("Resource/Abbreviation/LF")} " +
                    ((RePlugin.fuelRatiosByVol?.Value ?? false) ? "(2:1)" : "(5:2)");
            else if (mode.propellant.mixtureName == "Hydrolox")
                fuelStr = $"{OABLocalization.GetTranslation("Resource/Abbreviation/H")} : {OABLocalization.GetTranslation("Resource/Abbreviation/Ox")} " +
                    ((RePlugin.fuelRatiosByVol?.Value ?? false) ? "(5:2)" : "(5:32)");
            else if (mode.propellant.mixtureName == "Hypergolic")
                fuelStr = $"{OABLocalization.GetTranslation("Resource/Abbreviation/MP")} : {OABLocalization.GetTranslation("Resource/Abbreviation/LF")} " +
                    ((RePlugin.fuelRatiosByVol?.Value ?? false) ? "(5:1)" : "(15:2)");
            else if (mode.propellant.mixtureName == "XenonEC")
                fuelStr = $"{OABLocalization.GetTranslation("Resource/Abbreviation/Xe")} + {OABLocalization.GetTranslation("Resource/Abbreviation/EC")}";
            else if ("MonoPropellant|Hydrogen|Methane Air".Contains(mode.propellant.mixtureName))
                fuelStr = OABLocalization.GetTranslation("Resource/DisplayName/" + mode.propellant.mixtureName);
            if (fuelStr.Length > 0) dictToPopulate.Add(new KeyValuePair<string, string>(OABLocalization.GetTranslation("PartModules/Generic/Tooltip/Propellants"), fuelStr));
        }

        //[HarmonyPatch(typeof(StagePartDataContext), "GetFuelTotalAmount")]
        //[HarmonyPostfix]
        //public static void ReFuelTotal(int fuelIngredientIndex, ref float __result, StagePartDataContext __instance) {
        //    if (__result == 0.0f) return;
        //    if (!"Methalox|Hydrolox|Hypergolic".Contains(__instance.associatedEngineData.engineModes[0].propellant.mixtureName)) return; // 0 -> 1 for rapier
        //    GameInstance game = GameManager.Instance.Game;
        //    VesselDeltaVComponent deltaComp = game.GlobalGameState.GetGameState().GameState == GameState.VehicleAssemblyBuilder ?
        //        game.OAB.Current.Stats.MainAssembly.VesselDeltaV : game.ViewController.GetActiveVehicle().GetSimVessel().VesselDeltaV;
        //    // deltaComp.GetStage(__instance.associatedPart.InStageIndex).Parts.
        //    if (__instance.associatedEngineData != null && __instance.associatedEngineData.PropellantStates != null) {
        //        ResourceFlowRequestHandle reqHandle = __instance.associatedEngineData.PropellantStates[__instance.associatedEngineData.currentEngineModeIndex].requestHandle;
        //        ResourceFlowRequestManager.ManagedRequestWrapper reqWrap = null;
        //        bool reqValid = false;
        //        if (__instance.associatedPartComponent != null)
        //            reqValid = __instance.associatedPartComponent.PartResourceFlowRequestBroker.TryGetCurrentRequest(reqHandle, out reqWrap);
        //        else if (__instance.associatedPart != null && __instance.associatedPart.ResourceFlowRequestBroker != null)
        //            reqValid = __instance.associatedPart.ResourceFlowRequestBroker.TryGetCurrentRequest(reqHandle, out reqWrap);
        //        if (reqValid && reqWrap.instructions.Count > fuelIngredientIndex) {
        //            FlowInstructionConfig flowConfig = reqWrap.instructions[fuelIngredientIndex];
        //            if (flowConfig.ResourceContainerGroup != null) {
        //                double resTotal = flowConfig.ResourceContainerGroup.GetResourceCapacityUnits(flowConfig.FlowResource);
        //                RePlugin.Logger.LogInfo("flowResTotal: " + resTotal);
        //                foreach (ContainedResourceData resData in flowConfig.ResourceContainerGroup.GetAllResourcesContainedData()) {
        //                    RePlugin.Logger.LogInfo("this stored: " + resData.StoredUnits);
        //                    RePlugin.Logger.LogInfo("this total: " + resData.CapacityUnits);
        //                }
        //                // __result = (float)resTotal;
        //            }
        //        }
        //    }
        //}

        [HarmonyPatch(typeof(PartsManagerCore), nameof(PartsManagerCore.Initialize))]
        [HarmonyPostfix]
        public static void AddPartMgrMinBtn(PartsManagerCore __instance) {
            GameObject xBtn = __instance.transform.FindChildRecursive("BTN-Close")?.gameObject;
            if (xBtn == null) return;
            GameObject minBtn = UnityEngine.Object.Instantiate(xBtn, xBtn.transform.parent);
            minBtn.transform.SetSiblingIndex(minBtn.transform.parent.childCount - 2);
            Image imageComp = minBtn.GetChild("Icon")?.GetComponent<Image>();
            if (imageComp != null) {
                imageComp.sprite = null;
                // GameManager.Instance.Assets.Load<Sprite>("WB-ICO-Minimize", s => { imageComp.sprite = s; });
            }
            UIAction_Void_Button actionComp = minBtn.GetComponent<UIAction_Void_Button>();
            if (actionComp != null) {
                actionComp.enabled = false;
                ButtonExtended btnComp = minBtn.GetComponent<ButtonExtended>();
                if (btnComp != null) {
                    btnComp.onClick.AddListener(delegate {
                        RectTransform tformComp = __instance.GetComponent<RectTransform>();
                        if (tformComp == null) return;
                        float botEdgePad = 18;
                        float minSizeY = 100;
                        float maxSizeY = Math.Min((Screen.height / 2) + minSizeY - botEdgePad + tformComp.localPosition.y, 900);
                        tformComp.localPosition = new Vector2(tformComp.localPosition.x,
                            tformComp.localPosition.y + (tformComp.sizeDelta.y == minSizeY ? -(maxSizeY - minSizeY) : tformComp.sizeDelta.y - minSizeY));
                        tformComp.sizeDelta = new Vector2 (tformComp.sizeDelta.x,
                            tformComp.sizeDelta.y == minSizeY ? maxSizeY : minSizeY);
                    });
                }
            }
        }

        [HarmonyPatch(typeof(PartBehavior), nameof(PartBehavior.OnCollisionEnter))]
        [HarmonyPostfix]
        public static void AddImpactDamage(PartBehavior __instance, Collision c) {
            if (c == null || (__instance?.IsSimObjectDestroyed() ?? true) || __instance == null) return;
            if (c.relativeVelocity.magnitude > __instance.Model.CrashTolerance || c.relativeVelocity.magnitude < 0.1) return;
            if (__instance.SimObjectComponent.Guid == RePlugin.UIPart?.Guid) {
                RePlugin.UIPartImpacts = Tuple.Create(c.relativeVelocity.magnitude < RePlugin.UIPartImpacts.Item1 || RePlugin.UIPartImpacts.Item1 == 0 ? c.relativeVelocity.magnitude : RePlugin.UIPartImpacts.Item1,
                    c.relativeVelocity.magnitude > RePlugin.UIPartImpacts.Item2 ? c.relativeVelocity.magnitude : RePlugin.UIPartImpacts.Item2);
            }
            // if (c.relativeVelocity.magnitude < __instance.Model.CrashTolerance * 0.667) return;
            // ((c.relativeVelocity.magnitude - __instance.Model.CrashTolerance * 0.667) / __instance.Model.CrashTolerance) * 200.0;
            double dmg = Math.Pow(1.047, (c.relativeVelocity.magnitude / __instance.Model.CrashTolerance) * 100) - 1;
            if (__instance.SimObjectComponent.PartName == "eva_kerbal") {
                RePlugin.AddKerbalDamage(__instance.partOwner.SimObjectComponent.DisplayName, "Medicine_Impacts", dmg);
                if (c.relativeVelocity.magnitude > 3) ReUtil.PushNotify(__instance.partOwner.SimObjectComponent.DisplayName, "Hurt", NotificationImportance.Medium);
            } else ReUtil.TryAddDamage(__instance.SimObjectComponent, dmg, "Flight_Impacts");
        }

        [HarmonyPatch(typeof(RDCenterUIController), "InitializeTechTreeEnviroment")]
        [HarmonyPrefix]
        public static void AddTechTiers(RDCenterUIController __instance) {
            typeof(RDCenterUIController).GetField("_tiers", BindingFlags.Instance | BindingFlags.NonPublic)?.SetValue(__instance, 8);
            //FieldInfo sizeField = typeof(RDCenterUIController).GetField("_treeContainerHorizontalSize", BindingFlags.Instance | BindingFlags.NonPublic);
            //if (sizeField != null) sizeField.SetValue(__instance, (float)sizeField.GetValue(__instance) * 0.5);
        }

        [HarmonyPatch(typeof(RDCenterUIController), "UpdateFocusedTechNode")]
        [HarmonyPostfix]
        public static void ReTechPanel(RDCenterUIController __instance) {
            TechNodeView tNode = (TechNodeView)typeof(RDCenterUIController).GetField("_focusedNode", BindingFlags.Instance | BindingFlags.NonPublic)?.GetValue(__instance);
            FieldInfo textField = typeof(RDCenterUIController).GetField("_techNodeRequiredTechnologiesProperty", BindingFlags.Instance | BindingFlags.NonPublic);
            ScienceManager sciMgr = GameManager.Instance.Game.ScienceManager;
            Property<string> txtProp = (Property<string>)textField?.GetValue(__instance);
            // string path = "GameManager/Default Game Instance(Clone)/UI Manager(Clone)/Main Canvas/RDCenterUI(Clone)/Container/TechNodeInfo/Content/";
            // TextMeshProUGUI txtComp = GameObject.Find(path + "Footer/RequiredTechList")?.GetComponent<TextMeshProUGUI>();
            // if (txtComp == null) return;
            List<string> prqs = tNode?.AssociatedTechNode?.RequiredTechNodeIDs?.ToList();
            if (prqs?.All(t => sciMgr.IsNodeUnlocked(t)) ?? true) {
                if (tNode.CurrentNodeState == TechNodeView.NodeState.Visible) {
                    string cost = tNode.AssociatedTechNode.RequiredSciencePoints.ToString();
                    bool isSubTier = cost.StartsWith("2") || cost.StartsWith("3") || cost.StartsWith("6") || cost.StartsWith("8");
                    int lvl = tNode.AssociatedTechNode.TierToUnlock * 2 - (isSubTier ? 0 : 1);
                    List<string> sciReqs = ReUtil.careerSpecTechs.Where(p => p.Value.Any(t => tNode.AssociatedTechNode.ID.Contains(t))).Select(p => p.Key).Where(s => 
                        lvl > ReUtil.GetSciLevel(s)).ToList();
                    if (sciReqs?.Count > 0)
                        txtProp?.SetValue($"<color=#5FBFE4>{LocalizationManager.GetTranslation("Career/Level")} {lvl} " +
                            $"{LocalizationManager.GetTranslation(ReUtil.GetSciLocKey(sciReqs.First()))}{(sciReqs.Count == 1 ? "" : $" (+{sciReqs.Count - 1})")}</color>");
                    textField?.SetValue(__instance, txtProp);
                }
                return;
            } else if (prqs.Count == 1) return;
            prqs.RemoveAll(t => sciMgr.IsNodeUnlocked(t));
            // txtComp.text = LocalizationManager.GetTranslation(sciMgr.TechNodeDataStore.AvailableData[prqs.First()].NameLocKey) + (prqs.Count == 1 ? "" : $" (+{prqs.Count - 1})");
            txtProp?.SetValue(LocalizationManager.GetTranslation(sciMgr.TechNodeDataStore.AvailableData[prqs.First()].NameLocKey) + (prqs.Count == 1 ? "" : $" (+{prqs.Count - 1})"));
            textField?.SetValue(__instance, txtProp);
        }

        [HarmonyPatch(typeof(RDCenterUIController), "GetNodeState")]
        [HarmonyPostfix]
        public static void ReTechNodeState(RDCenterUIController __instance, TechNodeView node, ref TechNodeView.NodeState __result) {
            if (__result != TechNodeView.NodeState.Unlockable) return;
            string cost = node.AssociatedTechNode.RequiredSciencePoints.ToString();
            bool isSubTier = cost.StartsWith("2") || cost.StartsWith("3") || cost.StartsWith("6") || cost.StartsWith("8");
            List<string> sciReqs = ReUtil.careerSpecTechs.Where(p => p.Value.Any(t => node.AssociatedTechNode.ID.Contains(t))).Select(p => p.Key).Where(s =>
                (node.AssociatedTechNode.TierToUnlock * 2 - (isSubTier ? 0 : 1)) > ReUtil.GetSciLevel(s)).ToList();
            if (sciReqs?.Count > 0)
                __result = TechNodeView.NodeState.Visible;
        }

        [HarmonyPatch(typeof(RDCenterUIController), "OnUnlockTechNode")]
        [HarmonyPostfix]
        public static void AddCampaignAgencies(RDCenterUIController __instance) {
            TechNodeView tNode = (TechNodeView)typeof(RDCenterUIController).GetField("_focusedNode", BindingFlags.Instance | BindingFlags.NonPublic)?.GetValue(__instance);
            if (tNode == null) return;
            List<TechNodeData> tree = GameManager.Instance.Game.ScienceManager.TechNodeDataStore.AvailableData.Select(p => p.Value).ToList();
            bool addAgOrCrew = tree.Count(t => t.TierToUnlock == tNode.AssociatedTechNode.TierToUnlock && GameManager.Instance.Game.ScienceManager.IsNodeUnlocked(t.ID)) == 1;
            if (addAgOrCrew)
                for (int i = 0; i < tNode.AssociatedTechNode.TierToUnlock; i++)
                    GameManager.Instance.Game.SessionManager.KerbalRosterManager.CreateKerbalByName(ReUtil.GetRandomKerbalName(i + DateTime.Now.Second + DateTime.Now.Millisecond));
            foreach (string partID in tNode.AssociatedTechNode.UnlockedPartsIDs.Where(p => ReUtil.GetPartMfrKey(p)?.Length > 0 && RePlugin.TryGetPartRecord(p) == 0))
                RePlugin.AddPartRecord(partID, 0);
            addAgOrCrew = false;
            foreach (TechNodeData tech in tree.Where(t => t.RequiredTechNodeIDs.Contains(tNode.AssociatedTechNode.ID)))
                foreach (string partID in tech.UnlockedPartsIDs) {
                    string mfKey = ReUtil.GetPartMfrKey(partID);
                    if (mfKey?.Length > 0 && RePlugin.saveData.agencies.All(a => a.Name != mfKey)) {
                        addAgOrCrew = true;
                        RePlugin.saveData.agencies.Add(new ReAgency(mfKey));
                        ReUtil.PushNotify($"Missions/MissionGranter/Name/{mfKey}", "NewAgency", NotificationImportance.Low, false);
                    }
                }
            if (addAgOrCrew) return;
            if (tNode.AssociatedTechNode.TierToUnlock >= ReUtil.crewAgencies.Keys.Count(ca => RePlugin.saveData.agencies.Any(sa => sa.Name == ca)) - 2) {
                int total = tree.Count(t => t.TierToUnlock == tNode.AssociatedTechNode.TierToUnlock);
                int unlocked = tree.Count(t => t.TierToUnlock == tNode.AssociatedTechNode.TierToUnlock && GameManager.Instance.Game.ScienceManager.IsNodeUnlocked(t.ID));
                UnityEngine.Random.InitState(GameManager.Instance.Game.SessionGuidString.GetHashCode() + tNode.AssociatedTechNode.TierToUnlock * 100);
                // addAgOrCrew = total - locked >= UnityEngine.Random.Range(0, total);
                addAgOrCrew = Math.Pow(1.047, (unlocked / total) * 100) - 1 > UnityEngine.Random.value * 100;
            }
            if (!addAgOrCrew) return;
            int rand = UnityEngine.Random.Range(0, ReUtil.crewAgencies.Keys.Count(ca => RePlugin.saveData.agencies.All(sa => ca != sa.Name)));
            string agency = ReUtil.crewAgencies.Keys.Where(ca => RePlugin.saveData.agencies.All(sa => ca != sa.Name)).ToList()[rand];
            RePlugin.saveData.agencies.Add(new ReAgency(agency));
            ReUtil.PushNotify($"Missions/MissionGranter/Name/{agency}", "NewAgency", NotificationImportance.Low, false);
            foreach (string kerb in ReUtil.crewAgencies[agency])
                GameManager.Instance.Game.SessionManager.KerbalRosterManager.CreateKerbalByName(kerb.Split(' ')[0]);
        }

        [HarmonyPatch(typeof(UIWidget_viewport_ivaportrait), nameof(UIWidget_viewport_ivaportrait.SetEmpty))]
        [HarmonyPostfix]
        public static void AddPALPortraitName(UIWidget_viewport_ivaportrait __instance) {
            ButtonExtended btn = (ButtonExtended)typeof(UIWidget_viewport_ivaportrait).GetField("buttonEVA", BindingFlags.Instance | BindingFlags.NonPublic)?.GetValue(__instance);
            if (!btn?.interactable ?? false) __instance.SetKerbalName(LocalizationManager.GetTranslation("Diagnostic/PAL5000"));
        }

        [HarmonyPatch(typeof(IndicatorHeatWarning), "Awake")]
        [HarmonyPostfix]
        public static void FixHeatIndicator(IndicatorHeatWarning __instance) {
            typeof(IndicatorHeatWarning).GetField("_startThreshold", BindingFlags.Instance | BindingFlags.NonPublic)?.SetValue(__instance, 0.98f);
            typeof(IndicatorHeatWarning).GetField("_criticalThreshold", BindingFlags.Instance | BindingFlags.NonPublic)?.SetValue(__instance, 0.99f);
        }

    }

}

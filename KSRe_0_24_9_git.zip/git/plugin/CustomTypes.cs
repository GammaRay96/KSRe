﻿using I2.Loc;
using KSP.Game;
using KSP.Game.Science;
using KSP.Iteration.UI.Binding;
using KSP.Sim.impl;
using KSP.Sim.ResourceSystem;
using KSP.UI.Flight;
using Newtonsoft.Json;
using RTG;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using UnityEngine;

namespace KSRe {

    internal class ReUtil {

        internal static string GetColorForRange(double min, double max, double value) {
            if (value <= min) return "<color=#b4d455>";
            else if (value >= max) return "<color=#d45455>";
            string[] colorKeys = new string[11] { "b4d4", "c4d4", "d4d4", "d4c4", "d4b4", "d4a4", "d494", "d484", "d474", "d464", "d454" };
            return $"<color=#{colorKeys[(int)Math.Round((value - min) / (max - min) * 10)]}55>";
        }
        internal static string GetUllageStr(double gForce) {
            if (gForce == 0) return $"<color=#d45455>{LocalizationManager.GetTermTranslation($"PartModules/DamageEngine/Low")}</color>";
            else if (gForce > 0.035) return $"<color=#b4d455>{LocalizationManager.GetTermTranslation($"PartModules/DamageEngine/Nominal")}</color>";
            string[] colorKeys = new string[11] { "b4d4", "c4d4", "d4d4", "d4c4", "d4b4", "d4a4", "d494", "d484", "d474", "d464", "d454" };
            string nameKey = "Low";
            if (gForce > 0.0125) nameKey = "Marginal";
            if (gForce > 0.025) nameKey = "Nominal";
            return $"<color=#{colorKeys[(int)Math.Floor((0.035 - gForce) * 300)]}55>{LocalizationManager.GetTermTranslation($"PartModules/DamageEngine/{nameKey}")}</color>";
        }
        internal static string GetDamageStr(double damage) {
            if (damage <= 0) return $"<color=#b4d455>{LocalizationManager.GetTermTranslation($"PartModules/Damage/None")}</color>";
            string[] colorKeys = new string[11] { "b4d4", "c4d4", "d4d4", "d4c4", "d4b4", "d4a4", "d494", "d484", "d474", "d464", "d454" };
            string nameKey = "None";
            if (damage > 85) nameKey = "Heavy";
            else if (damage > 35) nameKey = "Medium";
            else if (damage > 10) nameKey = "Light";
            return $"<color=#{colorKeys[(int)Math.Floor(Math.Min(damage * 0.1, 10))]}55>{LocalizationManager.GetTermTranslation($"PartModules/Damage/{nameKey}")}</color>";
        }
        internal static string GetMachRegStr(double velocity) {
            string key = "Hyper";
            if (velocity < 273) key = "Sub";
            else if (velocity < 409) key = "Trans";
            else if (velocity < 1702) key = "Super";
            return LocalizationManager.GetTranslation($"Diagnostic/{key}sonic");
        }
        internal static string GetPartGradeStr(float pct) {
            string[] grades = new string[13] { "F", "D-", "D", "D+", "C-", "C", "C+", "B-", "B", "B+", "A-", "A", "A+" };
            return pct < 0.2f ? grades[0] : grades[Mathf.Clamp((int)Math.Round((pct - 0.2f) * 15), 1, 12)];
        }
        internal static int GetKerbalDmgInt(double value) {
            if (value < -50) return 0;
            else if (value < 0) return 1;
            else if (value > 90) return 11;
            return (int)Math.Floor(value / 10) + 2;
        }

        internal static bool IsGameSandbox() => GameManager.Instance.Game.SessionManager.ActiveGameMode == "SandboxMode";
        internal static bool IsPALActive(VesselComponent vessel = null, int level = 1, bool bypassVessel = false) {
            GameInstance Game = GameManager.Instance.Game;
            if (!bypassVessel) {
                VesselComponent vsl = vessel ?? GameManager.Instance.Game.ViewController?.GetActiveVehicle()?.GetSimVessel();
                if (vsl == null) return false;
                // if (vsl.IsKerbalEVA) return Game.ScienceManager?.IsNodeUnlocked($"tNode_pal5000_13") ?? false;
                bool hasProbe = vsl.SimulationObject?.PartOwner?.Parts?.Any(p => p.PartData.family == "0010-Probe") ?? false;
                if (!hasProbe) return false;
            }
            bool partTypeCheck = true;
            if (level == 4) partTypeCheck = RePlugin.UIPart.PartName.EndsWith("reactionwheel");
            else if (level == 6) partTypeCheck = "0100-Methalox|0101-DeepThrottle|0102-Cryogenic|0103-DeepSpace".Contains(RePlugin.UIPart.PartData.family) &&
                !"engine_0v_monoprop_puff|engine_0v_xenon_dawn".Contains(RePlugin.UIPart.PartName);
            else if (level == 5 || level == 10) partTypeCheck = RePlugin.UIPart.PartData.category == PartCategories.FuelTank && RePlugin.UIPart.PartData.family != "0070-Xenon";
            if (!partTypeCheck) return false;
            return Game.SessionManager.ActiveGameMode == "SandboxMode" || (Game.ScienceManager?.IsNodeUnlocked($"tNode_pal5000_{(level < 10 ? "0" : "")}{level}") ?? true);
        }
        
        internal static Dictionary<string, string[]> careerSpecTechs;
        internal static Dictionary<string, float> dmgSciRates;
        internal static Dictionary<string, string[]> mfParts;
        internal static Dictionary<string, string[]> crewAgencies;
        internal static Dictionary<int, float> sciLvls;
        internal static Dictionary<string, string[]> partKerbStats;
        internal static Dictionary<string, Texture2D> agencyFlags;

        internal static string GetPartMfrKey(string partName) => mfParts.FirstOrDefault(m => m.Value.Contains(partName)).Key ?? "";
        internal static ReAgency PlayerReAgency() => RePlugin.saveData.agencies?.FirstOrDefault(a => a.Name == PlayerAgencyName());
        internal static KerbalInfo GetKerbalForAgency(ReAgency agency) {
            KerbalInfo kerbal;
            GameManager.Instance.Game.SessionManager.KerbalRosterManager.TryGetKerbalByName(RePlugin.saveData.kerbals.FirstOrDefault(k => k?.agencyName == agency.Name).Name, out kerbal);
            return kerbal;
        }
        internal static List<KerbalDamage> GetKerbalsForAgency(ReAgency agency) => RePlugin.saveData?.kerbals?.Where(k => k?.agencyName == agency.Name)?.ToList() ?? new List<KerbalDamage>();
        internal static bool IsPlayerAgency(ReAgency agency) => agency?.Name == PlayerAgencyName();
        internal static string RandomTrait() {
            List<string> traits = careerSpecTechs.Keys.Where(s => !s.Contains("_")).ToList();
            List<string> traitsInUse = RePlugin.saveData.kerbals?.Select(k => k?.Trait)?.ToList() ?? new List<string>();
            if (traitsInUse.Count < traits.Count)
                traits.RemoveAll(t => traitsInUse.Contains(t));
            return traits[UnityEngine.Random.Range(0, traits.Count)];
        }
        internal static string PlayerTrait() => RePlugin.saveData.kerbals.FirstOrDefault(k => k?.agencyName == PlayerAgencyName())?.Trait;
        internal static string PlayerAgencyName() => GameManager.Instance.Game.AgencyManager.FindAgencyEntryFirst().AgencyName;

        internal static void TryAddDamage(PartComponent part, double damage, string dmgType) {
            if (part.TryGetModule(out PartComponentModule_DamageEngine moduleDmgEng) && moduleDmgEng != null)
                moduleDmgEng.AddDamage(damage, dmgType);
            else if (part.TryGetModule(out PartComponentModule_Damage moduleDmg) && moduleDmg != null)
                moduleDmg.AddDamage(damage, dmgType);
        }

        internal static int GetTotalScience() => !GameManager.Instance.Game.CampaignPlayerManager.TryGetMyCampaignPlayerEntry(out CampaignPlayerEntry player) ? 0 : 
            player.AllocatedSciencePoints + player.AvailableSciencePoints;
        internal static void AddScience(int amount, bool pushNotify = true) {
            GameManager.Instance.Game.SessionManager.UpdateMyAgencyAdditionalSciencePoints(GameManager.Instance.Game.SessionManager.GetMyAgencyAdditionalSciencePoints() + amount);
            if (!pushNotify) return;
            NotificationData notify = new NotificationData { Tier = NotificationTier.Alert, Importance = NotificationImportance.Low };
            notify.AlertTitle.LocKey = "Missions/TriumphWindow/AcceptScienceReward";
            notify.FirstLine.LocKey = "+" + amount;
            GameManager.Instance.Game.Notifications.ProcessNotification(notify);
        }
        internal static int GetSciLevel(string sciType) {
            //bool useSub = sciType.Contains("_");
            //List<int> subLvls = new List<int>();
            //if (useSub) {
            //    subLvls = sciLvlBonuses.Keys.Take(sciLvlBonuses.Count - 2).ToList();
            //    List<int> halfLvls = subLvls.Skip(1).Select(i => i / 2).ToList();
            //    subLvls.AddRange(halfLvls);
            //    subLvls = subLvls.Distinct().ToList();
            //    subLvls.Sort();
            //}
            // (!useSub ? sciLvlBonuses.Keys.ToList() : subLvls)
            int sci = PlayerReAgency().rocketScience.Where(s => s.Key.StartsWith(sciType)).Select(s => s.Value).Sum();
            return Mathf.Clamp(sciLvls.Keys.ToList().TakeWhile(l => l <= sci).Count() - 1 + 
                (PlayerTrait() == sciType ? 2 : 0), 0, sciLvls.Keys.ToList().Count - 1);
        }
        internal static float GetSciBonus(string sciType) => sciLvls.ElementAt(GetSciLevel(sciType.Contains("_") ? sciType.Split('_')[0] : sciType)).Value;
        internal static string GetSciLocKey(string sciType) {
            bool isSub = sciType.Contains("_");
            string[] keys = isSub ? sciType.Split('_') : new string[2] { sciType, "Title" };
            string locKey = sciType.StartsWith("Science") && isSub ? $"Science/Experiments/{keys[1]}/{keys[0].Replace("Science", "")}/ReportName" : $"Career/{keys[0]}/{keys[1]}";
            if (sciType.Contains("CrewObservation")) locKey = "Science/Experiments/CrewObservation/Data/ReportName";
            return locKey;
        }

        internal static void PushNotify(string name, string descKey, NotificationImportance color, bool rand = true, string obj = null) {
            UnityEngine.Random.InitState((name + descKey).GetHashCode() + DateTime.Now.Millisecond);
            NotificationData notify = new NotificationData { Tier = NotificationTier.Alert, TimeStamp = GameManager.Instance.Game.UniverseModel.UniverseTime, Importance = color };
            notify.AlertTitle.LocKey = name;
            notify.FirstLine.LocKey = $"{(rand || descKey.StartsWith("Wings") || descKey.StartsWith("Recovery") ? "KerbalLife" : "Career")}/Notifications/{descKey}{(rand ? UnityEngine.Random.Range(0, 3) + "" : "")}";
            if (obj != null) notify.FirstLine.ObjectParams = new object[1] { obj };
            GameManager.Instance.Game.Notifications.ProcessNotification(notify);
        }

        internal static string GetRandomKerbalName(int i) {
            string[] prefix = new string[] {
                "Ad", "Al", "Ald", "An", "Bar", "Bart", "Bil", "Billy-Bob", "Bob", "Bur", "Cal", "Cam", "Chad", "Cor", "Dan", "Der", "Des", "Dil", "Do", "Don", "Dood", "Dud", "Dun",
                "Ed", "El", "En", "Er", "Fer", "Fred", "Gene", "Geof", "Ger", "Gil", "Greg", "Gus", "Had", "Hal", "Han", "Har", "Hen", "Her", "Hud", "Jed", "Jen", "Jer", "Joe", "John",
                "Jon", "Jor", "Kel", "Ken", "Ker", "Kir", "Lan", "Lem", "Len", "Lo", "Lod", "Lu", "Lud", "Mac", "Mal", "Mat", "Mel", "Mer", "Mil", "Mit", "Mun", "Ned", "Neil", "Nel",
                "New", "Ob", "Or", "Pat", "Phil", "Ray", "Rib", "Rich", "Ro", "Rod", "Ron", "Sam", "Sean", "See", "Shel", "Shep", "Sher", "Sid", "Sig", "Son", "Thom", "Thomp", "Tom",
                "Wehr", "Wil"
            };
            string[] suffix = new string[] {
                "ald", "bal", "bald", "bart", "bas", "berry", "bert", "bin", "ble", "bles", "bo", "bree", "brett", "bro", "bur", "burry", "bus", "by", "cal", "can", "cas", "cott",
                "dan", "das", "den", "din", "do", "don", "dorf", "dos", "dous", "dred", "drin", "dun", "ely", "emone", "emy", "eny", "fal", "fel", "fen", "field", "ford", "fred",
                "frey", "frey", "frid", "frod", "fry", "furt", "gan", "gard", "gas", "gee", "gel", "ger", "gun", "hat", "ing", "ke", "kin", "lan", "las", "ler", "ley", "lie", "lin",
                "lin", "lo", "lock", "long", "lorf", "ly", "mal", "man", "min", "ming", "mon", "more", "mund", "my", "nand", "nard", "ner", "ney", "nie", "ny", "oly", "ory", "rey",
                "rick", "rie", "righ", "rim", "rod", "ry", "sby", "sel", "sen", "sey", "ski", "son", "sted", "ster", "sy", "ton", "top", "trey", "van", "vey", "vin", "vis", "well",
                "wig", "win", "wise", "zer", "zon", "zor"
            };
            UnityEngine.Random.InitState(i);
            return prefix[UnityEngine.Random.Range(0, prefix.Length)] + suffix[UnityEngine.Random.Range(0, suffix.Length)];
        }

        internal static string GetGameObjPath(GameObject obj) {
            string path = "/" + obj.name;
            while (obj.transform.parent != null) {
                obj = obj.transform.parent.gameObject;
                path = "/" + obj.name + path;
            }
            return path;
        }
    }

    public class KerbalDamage {
        // public IGGuid Id { get; private set; }
        public string Name { get; private set; }
        public string Trait { get; private set; }
        public string agencyName;
        public string status;
        public string celName;
        public Dictionary<string, double> damage;
        // public Dictionary<string, double> records;

        public KerbalDamage(string name, string trait, string agency) {
            Name = name;
            Trait = trait;
            agencyName = agency;
            damage = new Dictionary<string, double>();
            // records = new Dictionary<string, double>();
        }

    }

    public class ReAgency {
        public string Name { get; private set; }
        // public string leaderName;
        // public string leaderTrait;

        public Dictionary<string, int> rocketScience;
        public Dictionary<string, double> partRecords;

        public ReAgency(string name) {
            Name = name;
            rocketScience = new Dictionary<string, int>();
            partRecords = new Dictionary<string, double>();
        }

    }

    public class Repairer {

        public string Name { get; private set; }
        public string Guid { get; private set; }
        public string TargetGuid { get; private set; }
        // public float Estimate { get; private set; }

        public Repairer(string name, string guid, string targetGuid) {
            Name = name;
            Guid = guid;
            TargetGuid = targetGuid;
            // Estimate = estimate;
        }

    }

}
